#include  "iostream"
#include  "stdlib.h"
#include  "math.h"

using  namespace  std;

typedef  struct  
{  
   char  data[20];
   int   top;
} stackOPT;  //���ַ� 

typedef  struct  
{  
   float  data[20];
   int  top;
} stackOPD; //������ 

void  IniStackt( stackOPT&  stkt )   
{  stkt.top = -1;
}

void  IniStackd( stackOPD&  stkd )  

{  stkd.top = -1;
}

void  Pusht( stackOPT&  stkt,  char  x )
{  stkt.data[++stkt.top] = x;
}

void  Popt( stackOPT&  stkt,  char&  x )
{  x = stkt.data[stkt.top--];
}

char  Topt( stackOPT  stkt ) 
{  return  stkt.data[stkt.top]; 
}

void  Pushd( stackOPD&  stkd,  float  x ) 
{  stkd.data[++stkd.top] = x;
}

void  Popd( stackOPD&  stkd,  float&  x ) 
{  x = stkd.data[stkd.top--];
}

char read(char S[],int &k)//��ȡ����� 
{
	if(S[k]=='s'&&S[k+1]=='i'&&S[k+2]=='n')//��sin����Ϊs 
     {
       k=k+3;
	   return 's';
     } 
    if(S[k]=='c'&&S[k+1]=='o'&&S[k+2]=='s')//��cos����Ϊs 
    {
       k=k+3;
	   return 'c';
     } 
    if(S[k]=='l'&&S[k+1]=='o'&&S[k+2]=='g')//��log����Ϊl 
    {
    	k=k+3;
    	return 'l';
	}
	if(S[k]=='+')
	{
		k=k+1;
		return '+';
	}
	if(S[k]=='-')
	{
		k=k+1;
		return '-';
	}
	if(S[k]=='*')
	{
		k=k+1;
		return '*';
	}
	if(S[k]=='/')
	{
		k=k+1;
		return '/';
	}
	if(S[k]='^')
	{
		k=k+1;
		return '^';
	}

}

int  level( char  x )  //�涨��������ȼ� 
{  if  ( x == '=' )  return  0;
   if  ( x == '+' || x == '-' )  return  1;
   if  ( x == '*' || x == '/' )  return  2;
   if  ( x == 's' || x == 'c' || x == '^'|| x == 'l') return 3;
   if  ( x == '(' )  return  4;
}


int  cmp( char  x,  char  y ) //��������ȼ��Ƚ� 
{  int  lx = level( x ), ly = level( y );
   if  ( x == '(' )  lx = 0; //ջ�ڵ�'('���ȼ����   
   if  ( lx < ly )  return  -1; 
   if  ( lx = ly )  return  0;   
   return  1; 
}

float  opd( char  S[],  int&  k )//���ַ���ת��Ϊ���� 
{  int  i = 0;
   char  s[10];
   while  ( S[k] >= '0' && S[k] <= '9' || S[k] == '.' )  s[i++] = S[k++];
   s[i] = 0;
   return  atof( s );
}


void  cal( stackOPD&  stkd,  char  opt ) //�涨������������㷨�� 
{  float  x, y;
    
   switch  ( opt )   
   {  case '+': 
        Popd( stkd, y );  
        Popd( stkd, x ); 
        Pushd( stkd, x + y );  
        break;
      case '-':
       Popd( stkd, y );  
       Popd( stkd, x ); 
	   Pushd( stkd, x - y );  
	   break;
      case '*': 
	  Popd( stkd, y );  
      Popd( stkd, x ); 
	  Pushd( stkd, x * y ); 
	  break;
      case '/': 
	  Popd( stkd, y );  
      Popd( stkd, x ); 
	  Pushd( stkd, x / y );  
	  break;
      case '^': 
	  Popd( stkd, y );  
      Popd( stkd, x ); 
	  Pushd( stkd, pow(x,y)); break;
      case 's':   
      Popd( stkd, y );
	  Pushd( stkd, sin(y*3.1415/180)); 
	  break;
      case 'c': 
	  Popd( stkd, y );
	  Pushd( stkd, cos(y*3.1415/180)); 
	  break;
      case 'l': 
	  Popd( stkd, y );
	  Pushd( stkd, log(y));
	  break;
   }
}


float  calculator( char  S[] ) //���������庯�� 
{  int  k = 0, r, sign = 1;   
   char  opt;
   float  result;
   stackOPT  stkt;
   stackOPD  stkd;
   IniStackt( stkt );   
   IniStackd( stkd );
   Pusht( stkt, '=' ); //����ջ��ѹ��һ��= 
    while  ( S[k] != '=' && S[k] )   
   {  while  ( S[k] == ' ' )//�����ո� 
      k++;
      if  ( S[k] >= '0' && S[k] <= '9' || S[k] == '.' ) //������ѹ������ջ 
      {  Pushd( stkd, opd( S, k ));
         sign = 0;
      } 
		else 
      {  if  ( S[k] == ')' ) //�ж��Ƿ�Ϊ������  
         {  while  ( Topt( stkt ) != '(' ) 
            {  Popt( stkt, opt );
   	           cal( stkd, opt );
            }
            Popt( stkt, opt );  
            k++;  
         }  
		 else if(S[k]!='(')//�ж��Ƿ�Ϊ������ 
         {  
            char a;
			a=read(S,k); 
		    r = cmp( Topt( stkt ), a); 
			if  ( r == -1 )
			Pusht( stkt, a );  
			else 
	   	    {  Popt( stkt, opt );  
		       cal( stkd, opt );
		       Pusht(stkt,a);
            }
		}
		else//����ǡ������������ѹ��һ��0+ 
		{
			sign=1;
			Pusht(stkt,S[k]);
			Pushd(stkd,0); 
			Pusht(stkt,'+');
			k=k+1;
		}
	  }

   }
   if  ( ! S[k] )  cout << '='; //��ջ��ʣ�����ֺͷ������  
   while  ( Topt( stkt ) != '=' )  
   {  Popt( stkt, opt );
	  cal( stkd, opt );
   } 
   Popd( stkd, result );  
   return  result;
}


int  main()
{ char  S[100];
   gets( S );   
   cout << endl << S;
   cout << calculator( S ) << endl << endl; 
   system( "pause" );
   return  1;
}


