<style lang="less">
  @import './login.less';
</style>

<template>
  <div class="login">
    <div class="login-con">
      <Card icon="log-in" title="欢迎登录" :bordered="false">
        <div class="form-con">
          <login-form @on-success-valid="handleSubmit"></login-form>
          <p class="login-tip">输入任意用户名和密码即可</p>
        </div>
      </Card>
    </div>
  </div>
</template>

<script>
import LoginForm from '_c/login-form'
import { mapActions } from 'vuex'
import {addUser, modifyPassword} from "../../api/user";
import {getMessage} from "../../api/student";
import {getUserId, setCount} from "../../libs/util";
export default {
  data() {
    return {
      password: ''
    }
  },
  components: {
    LoginForm
  },
  methods: {
    ...mapActions([
      'handleLogin',
    ]),
    handleSubmit ({ id, password }) {
      this.handleLogin({ id, password }).then(res => {
        // 登录成功，判断用户身份，是学生的话请求系统通知消息
        let first = res.body.isFirstLogin
        // 首次登录
        if (first === 1) {
          this.$Modal.confirm({
            render: (h) => {
              return h('Input', {
                props: {
                  value: this.value,
                  autofocus: true,
                  placeholder: '首次登录请修改密码'
                },
                on: {
                  input: (val) => {
                    this.password = val;
                  }
                }
              })
            },
            onOk: () => {
              // 发送请求，修改密码
              console.log('Ok click')
              modifyPassword(id, this.password).then(
                res => {
                  this.$Message.success('修改成功')
                }
              )
            },
            onCancel: () => {
              console.log('cancel click')
            }
          })
        }

        let role = res.body.role
        switch (role) {
          case 1: // 学生
            // 加载提交作业提醒
            const stuId = getUserId()
            getMessage(stuId).then(
              res => {
                const messages = res.body
                if (messages.length > 0) {
                  setCount(messages.length)
                  return
                }
                setCount(0)
              }
            )
            this.$router.push({
              name: 'student'
            })
            break
          case 2:
            this.$router.push({
              name: 'teacher'
            })
            break
          case 3:
            this.$router.push({
              name: 'admin'
            })
            break
        }
      })
    },
  }
}
</script>

<style>

</style>
