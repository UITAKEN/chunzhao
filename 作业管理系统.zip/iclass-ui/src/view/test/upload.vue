<template>
  <Upload action="http://localhost:8080/upload" name="excel"
          :format="['.xlsx']"
          accept=".xlsx"
          :on-success="handleSuccess"
          :on-error="handleError"
          :with-credentials=true
  >
    <Button type="primary" icon="ios-cloud-upload-outline">Upload files</Button>
  </Upload>
</template>
<script>
  export default {
    methods: {
      handleSuccess(response) {
        console.log(response)
      },
      handleError (err) {
        console.log(err)
      }
    }
  }
</script>
