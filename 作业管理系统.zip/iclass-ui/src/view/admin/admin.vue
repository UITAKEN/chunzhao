<template>
  <div class="layout">
    <Row type="flex" style="height: 100%;">
      <Col span="5" class="layout-menu-left">
      <Menu theme="dark" width="auto" :open-names="['1','2']">
        <div class="layout-logo-left">
          管理员
        </div>
        <Submenu name="1">
          <template slot="title">
            <Icon type="ios-navigate"></Icon>
            用户管理
          </template>
          <MenuItem name="1-1" to="/admin/add">添加用户</MenuItem>
          <!--用户查询包括信息修改，用户删除，用户查找-->
          <MenuItem name="1-2" to="/admin/view">用户浏览</MenuItem>
        </Submenu>
        <Submenu name="2">
          <template slot="title">
            <Icon type="ios-keypad"></Icon>
            导入用户
          </template>
          <MenuItem name="2-1" to="/admin/import">批量导入</MenuItem>
        </Submenu>
      </Menu>
      </Col>
      <Col span="19">
      <div class="layout-content" style="height: 90%;">
        <div class="layout-content-main">
          <router-view></router-view>
        </div>
      </div>
      <div class="layout-copy">
        2018-2019 &copy; 北京邮电大学
      </div>
      </Col>
    </Row>
  </div>
</template>
<script>
  export default {
    name: 'admin',
    data () {
      return {
        theme: 'dark'
      }
    },
    methods: {

    }
  }
</script>

<style scoped>
  .layout{
    border: 1px solid #d7dde4;
    background: #f5f7f9;
    position: relative;
    height: 100%;
  }
  .layout-breadcrumb{
    padding: 10px 15px 0;
  }
  .layout-content{
    min-height: 200px;
    margin: 15px;
    overflow: hidden;
    background: #fff;
    border-radius: 4px;
  }
  .layout-content-main{
    padding: 10px;
  }
  .layout-copy{
    text-align: center;
    padding: 15px 0 20px;
    color: #9ea7b4;
  }
  .layout-menu-left{
    background: #464c5b;
  }
  .layout-header{
    height: 60px;
    background: #fff;
    box-shadow: 0 1px 1px rgba(0,0,0,.1);
  }
  .layout-logo-left{
    width: 90%;
    height: 30px;
    line-height: 30px;
    background: #ffffff;
    border-radius: 3px;
    margin: 15px auto;
    text-align: center;
    font-size: 20px;
    /*font-family: "Monotype Corsiva",serif;*/
  }
</style>
