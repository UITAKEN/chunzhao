<template>
  <div>
    <Card style="text-align: center">
      <h4 slot="title">
        批量导入
      </h4>
      <Table stripe border :columns="columns" :data="tableData" height="600"></Table>
    </Card>

    <div style="display: flex; flex-direction: row; margin-top: 10px">
      <Upload action="http://localhost:8080/upload"
              name="excel"
              :on-success="handleSuccess"
              :on-error="handleError"
              :with-credentials=true
              style="display: inline;">
        <Button type="primary"
                icon="ios-cloud-upload-outline"
                style="height: 40px;">
          导入Excel文件</Button>
      </Upload>

      <Button style="height: 40px;
               margin-left: 10px"
              type="info" @click="handleSubmit"> &nbsp; 保存 &nbsp; </Button>
    </div>
  </div>
</template>
<script>
  import { getExcelData, saveExcelData } from "../../api/admin";

  export default {
    data () {
      return {
        columns: [
          {
            title: '教工号/学号',
            key: 'id',
            align: 'center'
          },
          {
            title: '姓名', // 昵称
            key: 'name',
            align: 'center'
          },
          {
            title: '密码',
            key: 'password',
            align: 'center'
          },
          {
            title: '角色',
            key: 'role',
            align: 'center'
          },
          {
            title: '首次登陆',
            key: 'isFirstLogin',
            align: 'center'
          },
        ],
        tableData: []
      }
    },

    methods: {
      handleSuccess(response) {
        console.log(response)
        response.body.forEach((item) => {
          switch (item.role) {
            case 1:
              item.role = '学生'
              break
            case 2:
              item.role = '教师'
              break
            case 3:
              item.role = '管理员'
              break
          }
          item.isFirstLogin = item.isFirstLogin === 1 ? '是' : '否'
          this.tableData.push(item)
        })
      },
      handleError (err) {
        console.log(err)
      },
      handleSubmit () {
        saveExcelData().then(
          res => {
            console.log(res)
            if (res.success) {
              this.tableData = []
              this.$Message.success(res.body)
            }
            else {
              this.$Message.error(res.error)
            }
          }
        )
      }
    },
    mounted () {
      getExcelData().then(
        res => {
          this.tableData = [];
          res.body.forEach((item) => {
            switch (item.role) {
              case 1:
                item.role = '学生'
                break
              case 2:
                item.role = '教师'
                break
              case 3:
                item.role = '管理员'
                break
            }
            item.isFirstLogin = item.isFirstLogin === 1 ? '是' : '否'
            this.tableData.push(item)
          })
        }
      )
    },
    created () {
      // 发送请求，获取数据
    }
  }
</script>
