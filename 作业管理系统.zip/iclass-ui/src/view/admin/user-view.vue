<!--用户浏览界面-->
<!--包含用户查询，删除，浏览功能-->
<template>
  <div>
    <tables></tables>
  </div>
</template>

<script type="text/ecmascript-6">
  import tables from '@/view/tables/tables'
  export default {
    name: '',
    components: {
      tables
    }
  }
</script>

<style scoped>

</style>
