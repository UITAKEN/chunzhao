<template>
  <div class="layout">
    <Row type="flex" style="height: 100%;">
      <Col span="5" class="layout-menu-left">

      <Menu theme="dark" width="auto" :open-names="['1','2']">
        <div class="layout-logo-left">
          学生
        </div>
        <Submenu name="1">
          <template slot="title">
            <Icon type="ios-navigate"></Icon>
            课程管理
          </template>
          <MenuItem name="1-1" to="/student/course">课程查询</MenuItem>
        </Submenu>
        <Submenu name="3">
          <template slot="title">
            <Icon type="ios-navigate"></Icon>
            分组管理
          </template>
          <MenuItem name="3-1" to="/student/group">创建分组</MenuItem>
          <MenuItem name="3-2" to="/student/groupList">浏览分组</MenuItem>
        </Submenu>
        <Submenu name="2">
          <template slot="title">
            <Icon type="ios-keypad"></Icon>
            作业管理
          </template>
          <MenuItem name="2-1" to="/student/work">浏览作业</MenuItem>
          <MenuItem name="2-2" to="/student/submit">作业提交</MenuItem>
          <MenuItem name="2-3" to="/student/score">成绩查询</MenuItem>

          <MenuItem name="2-4" to="/student/notice">作业通知</MenuItem>
        </Submenu>
      </Menu>
      </Col>
      <Col span="19">
      <div class="layout-content" style="height: 90%;">
        <div class="layout-content-main">
          <router-view></router-view>
        </div>
      </div>
      <div class="layout-copy">
        2018-2019 &copy; 北京邮电大学
      </div>
      </Col>
    </Row>
  </div>
</template>
<script>
  export default {
    name: 'admin',
    data () {
      return {
        theme: 'dark'
      }
    },
    methods: {

    }
  }
</script>

<style scoped>
  .layout{
    border: 1px solid #d7dde4;
    background: #f5f7f9;
    position: relative;
    height: 100%;
  }
  .layout-breadcrumb{
    padding: 10px 15px 0;
  }
  .layout-content{
    min-height: 200px;
    margin: 15px;
    overflow: hidden;
    background: #fff;
    border-radius: 4px;
  }
  .layout-content-main{
    padding: 10px;
    overflow: auto;
    /*height: 1000px;*/
  }
  .layout-copy{
    text-align: center;
    padding: 15px 0 20px;
    color: #9ea7b4;
  }
  .layout-menu-left{
    background: #464c5b;
  }
  .layout-header{
    height: 60px;
    background: #fff;
    box-shadow: 0 1px 1px rgba(0,0,0,.1);
  }
  .layout-logo-left{
    width: 90%;
    height: 30px;
    line-height: 30px;
    background: #ffffff;
    border-radius: 3px;
    margin: 15px auto;
    text-align: center;
    font-size: 20px;
    /*font-family: "Monotype Corsiva",serif;*/
  }
</style>
