<template>
  <div class="layout">
    <Row type="flex" style="height: 100%;">
      <Col span="5" class="layout-menu-left">

      <Menu theme="dark" width="auto" :open-names="['1','2']">
        <div class="layout-logo-left">
          教师
        </div>
        <Submenu name="1">
          <template slot="title">
            <Icon type="ios-navigate"></Icon>
            课程管理
          </template>
          <MenuItem name="1-1" to="/teacher/course">创建课程</MenuItem>
          <!--用户查询包括信息修改，用户删除，用户查找-->
          <MenuItem name="1-2" to="/teacher/allCourses">课程浏览</MenuItem>
        </Submenu>
        <Submenu name="2">
          <template slot="title">
            <Icon type="ios-keypad"></Icon>
            学生管理
          </template>
          <MenuItem name="2-0" to="/teacher/addStu">添加学生</MenuItem>
          <MenuItem name="2-1" to="/teacher/select">导入名单</MenuItem>
          <MenuItem name="2-2" to="/teacher/stuList">查看名单</MenuItem>
        </Submenu>
        <Submenu name="3">
          <template slot="title">
            <Icon type="ios-keypad"></Icon>
            成绩管理
          </template>
          <MenuItem name="3-1" to="/teacher/select">成绩录入</MenuItem>
          <MenuItem name="3-2" to="/teacher/scoreList">成绩浏览</MenuItem>
        </Submenu>
        <Submenu name="4">
          <template slot="title">
            <Icon type="ios-keypad"></Icon>
            分组管理
          </template>
          <MenuItem name="4-1" to="/teacher/groupConf">分组配置</MenuItem>
          <MenuItem name="4-2" to="/teacher/confList">配置列表</MenuItem>
          <MenuItem name="4-3" to="/teacher/groupList">分组列表</MenuItem>
        </Submenu>

        <Submenu name="5">
          <template slot="title">
            <Icon type="ios-keypad"></Icon>
            作业管理
          </template>
          <MenuItem name="5-1" to="/teacher/addTask">添加作业</MenuItem>
          <MenuItem name="5-2" to="/teacher/taskList">浏览作业</MenuItem>
        </Submenu>
      </Menu>
      </Col>
      <Col span="19">
      <div class="layout-content" style="height: 90%;">
        <div class="layout-content-main">
          <router-view></router-view>
        </div>
      </div>
      <div class="layout-copy">
        2018-2019 &copy; 北京邮电大学
      </div>
      </Col>
    </Row>
  </div>
</template>
<script>
  export default {
    name: 'admin',
    data () {
      return {
        theme: 'dark'
      }
    },
    methods: {

    }
  }
</script>

<style scoped>
  .layout{
    border: 1px solid #d7dde4;
    background: #f5f7f9;
    position: relative;
    height: 100%;
  }
  .layout-content{
    min-height: 200px;
    margin: 10px;
    overflow: hidden;
    background: #fff;
    border-radius: 4px;
  }
  .layout-content-main{
    padding: 10px;
    overflow: auto;
    /*height: 1000px;*/
  }
  .layout-copy{
    text-align: center;
    padding: 15px 0 20px;
    color: #9ea7b4;
  }
  .layout-menu-left{
    background: #464c5b;
  }
  .layout-header{
    height: 60px;
    background: #fff;
    box-shadow: 0 1px 1px rgba(0,0,0,.1);
  }
  .layout-logo-left{
    width: 90%;
    height: 30px;
    line-height: 30px;
    background: #ffffff;
    border-radius: 3px;
    margin: 15px auto;
    text-align: center;
    font-size: 20px;
    /*font-family: "Monotype Corsiva",serif;*/
  }
</style>
