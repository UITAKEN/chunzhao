<template>
  <div style="display: flex; text-align: center">
    <h1 style="margin: 0 auto; text-align: center">个人中心</h1>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    name: ''
  }
</script>

<style scoped>

</style>
