<template>
  <div id="table-root">
    <Card>
      <tables ref="tables" editable searchable search-place="top" v-model="tableData" :columns="columns" @on-delete="handleDelete"/>
        <Button style="height: 40px;
                margin-top: 5px" type="primary" @click="exportExcel">导出Excel文件</Button>
    </Card>

    <Modal v-model="modal" @on-ok="handleOK">
      <Form :model="formItem" :label-width="80">
        <FormItem label="教工号/学号">
          <Input v-model="formItem.id" placeholder="请输入教工号/学号..."></Input>
        </FormItem>
        <FormItem label="密码">
          <Input v-model="formItem.password" placeholder="请输入教工号/学号..."></Input>
        </FormItem>
        <FormItem label="姓名">
          <Input v-model="formItem.name" placeholder="请输入姓名..."></Input>
        </FormItem>
        <FormItem label="身份">
          <Select v-model="formItem.role">
            <Option value="3">管理员</Option>
            <Option value="2">教师</Option>
            <Option value="1">学生</Option>
          </Select>
        </FormItem>
      </Form>
    </Modal>
  </div>
</template>

<script>
  import Tables from '_c/tables'
  import { getAllUsers } from '@/api/admin'
  import { getStudentInfo } from "@/api/student";
  import { getTeacherInfo } from "@/api/teacher";
  import { delUser } from "@/api/user";

  import {mapActions} from 'vuex'
  export default {
    name: 'tables_page',
    components: {
      Tables
    },
    data () {
      return {
        modal: false,
        formItem: {
          id: '2015211176',
          role: '1',
          name: '蒋丹阳',
          password: '2015211176'
        },
        columns: [
          {title: '教工号/学号', key: 'id', sortable: true, align: 'center'},
          {title: '姓名', key: 'name', sortable: true, align: 'center'},
          {title: '首次登陆', key: 'isFirstLogin', align: 'center'},
          {title: '身份', key: 'role', align: 'center'},

          {
            title: '操作',
            key: 'action',
            width: 220,
            align: 'center',
            render: (h, params) => {
              return h('div', [
                h('Button', {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.show(params.index)
                    }
                  }
                }, '查看'),
                h('Button', {
                  props: {
                    type: 'warning',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.modifyUser(params.index)
                      this.modal = true
                    }
                  }
                }, '修改'),
                h('Button', {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.remove(params.index)
                    }
                  }
                }, '删除')
              ]);
            }
          }
        ],
        tableData: [

        ]
      }
    },
    methods: {
      ...mapActions([
        'submitUser'
      ]),
      handleOK() {
        console.log("Ok click")
        const form = this.formItem
        const user = {
          name: form.name,
          role: form.role,
          id: form.id,
          classId: '',
          department: '', // 学院
          password: form.password,
          userName: '',
          major: ''
        }
        this.submitUser(user).then(

          res => {
            this.$Message.success("修改成功")
            getAllUsers().then(
              res => {
                let users = res.body;
                const getRoleName = (roleId) => {
                  switch (roleId) {
                    case 1:
                      return '学生'
                    case 2:
                      return '教师'
                    case 3:
                      return '管理员'
                  }
                }

                const isFirst = (first) => {
                  if (first === 1) return '是'
                  return '否'
                }
                users.forEach((user) => {
                  let unit = {
                    id: user.id.toString(),
                    name: user.name,
                    isFirstLogin: isFirst(user.isFirstLogin),
                    role: getRoleName(user.role)
                  }
                  this.tableData.push(unit)
                })
                console.log(res.body)
              }
            )
          }
        )
      },
      handleDelete (params) {
        console.log(params)
      },
      exportExcel () {
        this.$refs.tables.exportCsv({
          filename: `table-${(new Date()).valueOf()}.csv`
        })
      },
      handleSuccess(response) {
        console.log(response)
      },
      handleError (err) {
        console.log(err)
      },
      modifyUser(index) {
        const user = this.tableData[index]

        switch (user.role) {
          case '管理员':
            user.role = '3'
            break
          case '教师':
            user.role = '2'
            break
          case '学生':
            user.role = '1'
            break
        }
        console.log(user)
        this.formItem = user;
        // this.formItem
      },
      show (index) {
        let user = this.tableData[index];
        console.log(user)
        switch (user.role) {
          case '管理员':
            this.$Modal.info({
              title: '详细信息',
              content: `None`
            })
            break
          case '教师':
            getTeacherInfo(user.id).then(
              res => {
                let teacher = res.body
                this.$Modal.info({
                  title: '详细信息',
                  content: `学院：${teacher.department}<br>职称：${teacher.title}`
                })
              }
            )
            break;
          case '学生':
            getStudentInfo(user.id).then(
              res => {
                let stu = res.body
                user.dep = stu.department
                user.major = stu.major
                user.classId = stu.classId
                this.$Modal.info({
                  title: '详细信息',
                  content: `学院：${user.dep}<br>专业：${user.major}<br>班级：${user.classId}`
                })
              }
            )
            break
        }

      },
      remove (index) {
        let user = this.tableData[index];
        delUser(user.id).then(
          res => {
            if (res.success) { // 删除成功
              this.tableData.remove(user)
            }
            else {
              // 删除失败
            }
          }
        )
      },
    },
    mounted () {
      getAllUsers().then(
        res => {
          let users = res.body;
          const getRoleName = (roleId) => {
            switch (roleId) {
              case 1:
                return '学生'
              case 2:
                return '教师'
              case 3:
                return '管理员'
            }
          }

          const isFirst = (first) => {
            if (first === 1) return '是'
            return '否'
          }
          users.forEach((user) => {
            let unit = {
              id: user.id.toString(),
              name: user.name,
              isFirstLogin: isFirst(user.isFirstLogin),
              role: getRoleName(user.role)
            }
            this.tableData.push(unit)
          })
          console.log(res.body)
        }
      )
    },

    created() {

    }

  }
</script>

<style scoped>
  #table-root {
    height: 760px;
  }
</style>
