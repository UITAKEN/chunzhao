<template>
  <Upload action="http://localhost:8080/upload" name="excel" with-credentials="true">
    <Button type="info" icon="ios-cloud-upload-outline">Upload files</Button>
  </Upload>
</template>
<script>
  export default {

  }
</script>
