<template>
  <div id="home">
    <main-page></main-page>
  </div>
</template>

<script>
// @ is an alias to /src
import MainPage from '@/components/main'

export default {
  name: 'home',
  components: {
    MainPage
  },

}
</script>

<style>
  #home {
    /*!*display: flex;*!*/
    /*!*flex-direction: column;*!*/
    /*text-align: center;*/
    /*margin-top: 100px;*/
  }
</style>
