import Main from '@/components/main'
export default [
  {
    path: '/upload',
    name: 'upload-test',
    meta: {
      title: 'Login - 登录',
      // hideInMenu: true
    },
    component: () => import('@/view/upload.vue')
  },
  {
    path: '/login',
    name: 'login',
    meta: {
      title: 'Login - 登录',
      // hideInMenu: true
    },
    component: () => import('@/view/login/login.vue')
  },

  {
    path: '/profile',
    name: 'profile',
    meta: {
      title: '个人中心',
      // hideInMenu: true
    },
    component: () => import('@/view/profile.vue')
  },

  {
    path: '/',
    name: 'home',
    redirect: '/login',
    component: Main,
    meta: {
      hideInMenu: true,
      notCache: true
    },
    children: [
      {
        path: 'admin',
        name: 'admin',
        meta: {
          hideInMenu: true,
          title: '管理员',
          notCache: true,
        },
        component: () => import('@/view/admin/admin'),
        children: [
          {
            path: 'add',
            name: 'add',
            component: () => import('@/components/user-form/user-form')
          },
          {
            path: 'view',
            name: 'view',
            component: () => import('@/view/admin/user-view')
          },
          {
            path: 'import',
            name: 'import',
            component: () => import('@/view/admin/user-import'),
          }
        ]
      },
      {
        path: 'teacher',
        name: 'teacher',
        meta: {
          hideInMenu: true,
          title: '教师',
          // notCache: true,
          // icon: 'md-home'
        },
        component: () => import('@/view/teacher/teacher'),
        children: [
          {
            path: 'course',
            name: 'teaCourse',
            component: () => import('@/components/teacher/course-form')
          },
          {
            path: 'allCourses',
            name: 'allCourses',
            component: () => import('@/components/teacher/course-list')
          },
          {
            path: 'select',
            name: 'select',
            component: () => import('@/components/teacher/student-course'),
          },
          {
            path: 'stuList',
            name: 'stuList',
            component: () => import('@/components/teacher/stu-list'),
          },
          { // 分组配置界面
            path: 'groupConf',
            name: 'groupConf',
            component: () => import('@/components/teacher/group-form'),
          },
          { // 分组配置列表界面
            path: 'confList',
            name: 'confList',
            component: () => import('@/components/teacher/conf-list'),
          },
          { // 所有的小组列表
            path: 'groupList',
            name: 'groupList',
            component: () => import('@/components/teacher/group-list'),
          },
          { // 添加作业
            path: 'addTask',
            name: 'addTask',
            component: () => import('@/components/teacher/task-form'),
          },
          { // 添加作业
            path: 'taskList',
            name: 'taskList',
            component: () => import('@/components/teacher/task-list'),
          },
          { // 添加作业
            path: 'scoreList',
            name: 'scoreList',
            component: () => import('@/components/teacher/score-list'),
          },
          { // 添加作业
            path: 'addStu',
            name: 'addStu',
            component: () => import('@/components/teacher/student-add'),
          }
        ]
      },
      {
        path: 'student',
        name: 'student',
        meta: {
          hideInMenu: true,
          title: '学生',
          // notCache: true,
          // icon: 'md-home'
        },
        component: () => import('@/view/student/student'),
        children: [
          {
            path: 'course',
            name: 'stuCourse',
            component: () => import('@/components/student/course-list')
          },
          {
            path: 'group',
            name: 'group',
            component: () => import('@/components/student/group-form')
          },
          {
            path: 'work',
            name: 'work',
            component: () => import('@/components/student/work-list'),
          },
          {
            path: 'submit',
            name: 'submit',
            component: () => import('@/components/student/submit'),
          },
          {
            path: 'score',
            name: 'score',
            component: () => import('@/components/student/score-list'),
          },
          {
            path: 'notice',
            name: 'notice',
            component: () => import('@/components/student/notice-list'),
          },
          {
            path: 'groupList',
            name: 'groupList',
            component: () => import('@/components/student/group-list'),
          }
        ]
      }
    ]
  },
  {
    path: '/upload',
    name: 'upload',
    meta: {
      title: '上传'
    },
    component: () => import('../view/test/upload')
  },
  // {
  //   path: '/teacher',
  //   name: 'teacher',
  //   // route level code-splitting
  //   // this generates a separate chunk (about.[hash].js) for this route
  //   // which is lazy-loaded when the route is visited.
  //   component: () => import(/* webpackChunkName: "about" */ '../view/tables/tables.vue')
  // },
  {
    path: '/401',
    name: 'error_401',
    meta: {
      hideInMenu: true
    },
    component: () => import('@/view/error-page/401.vue')
  },
  {
    path: '/500',
    name: 'error_500',
    meta: {
      hideInMenu: true
    },
    component: () => import('@/view/error-page/500.vue')
  },
  {
    path: '*',
    name: 'error_404',
    meta: {
      hideInMenu: true
    },
    component: () => import('@/view/error-page/404.vue')
  }
]
