import Vue from 'vue'
import Router from 'vue-router'
import routes from './routers'
import {getLoginStatus, getUserInfo, getUserRole} from '@/libs/util'

import store from '@/store'

import iView from 'iview'

import config from '@/config'


Vue.use(Router)

const router = new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  routes: routes
})

const LoginPageName = 'login'
const StuPage = 'student'
const AdminPage = 'admin'
const TeacherPage = 'teacher'



router.beforeEach((to, from, next) => {
  iView.LoadingBar.start()
  const loginStatus = getLoginStatus();
  console.log(loginStatus)
  // console.log('vue-router', jsessionid)
  if (!loginStatus && to.name !== LoginPageName) {
    next({
      name: LoginPageName // 跳转到登录页
    })
  } else if (!loginStatus && to.name === LoginPageName) {
    next()
  } else if (loginStatus && to.name === LoginPageName) {
    let role = getUserRole();
    console.info('router 跳转',role)
    switch (role) {
      case 'admin':
        next({
          name: AdminPage
        })
        break
      case 'teacher':
        next({
          name: TeacherPage
        })
        break
      case 'stu':
        next({
          name: StuPage
        })
        break
    }
  }
  next();
})

router.afterEach(to => {
  iView.LoadingBar.finish()
  window.scrollTo(0, 0)
})

export default router
