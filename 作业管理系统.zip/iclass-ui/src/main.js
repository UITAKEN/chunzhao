import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import iView from 'iview'
import config from '@/config'

// import ElementUI from 'element-ui';
// import 'element-ui/lib/theme-chalk/index.css';

import 'iview/dist/styles/iview.css'
import './index.less'
import '@/assets/icons/iconfont.css'

Vue.use(iView)
// Vue.use(ElementUI);

Vue.config.productionTip = false

Vue.prototype.$config = config

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
