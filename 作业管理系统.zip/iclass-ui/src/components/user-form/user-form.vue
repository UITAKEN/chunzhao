<template>
  <div class="user-root">
    <Form :model="formItem" :label-width="80">
      <FormItem label="姓名">
        <Input v-model="formItem.name" placeholder="请输入姓名..."></Input>
      </FormItem>
      <FormItem label="角色">
        <Select v-model="formItem.role">
          <Option value="3">管理员</Option>
          <Option value="2">教师</Option>
          <Option value="1">学生</Option>
        </Select>
      </FormItem>
      <FormItem label="教工号/学号">
        <Input v-model="formItem.id" placeholder="请输入教工号/学号..."></Input>
      </FormItem>
      <!--<FormItem label="班级" v-show="false">-->
        <!--<Input v-model="formItem.password"></Input>-->
      <!--</FormItem>-->
      <!--<FormItem label="学院">-->
        <!--<Input v-model="formItem.dep" placeholder="请输入学院..."></Input>-->
      <!--</FormItem>-->
      <!--<FormItem label="班级">-->
        <!--<Input :disabled="formItem.role !== '1'" v-model="formItem.classId" placeholder="请输入班级..."></Input>-->
      <!--</FormItem>-->
      <!--<FormItem label="专业">-->
        <!--<Input :disabled="formItem.role !== '1'" v-model="formItem.major" placeholder="请输入专业"></Input>-->
      <!--</FormItem>-->
      <FormItem style="text-align: center">
        <Button type="primary" @click="handleSubmit" style="width: 100px;">提交</Button>
        <!--<Button type="info" style="margin-left: 8px">取消</Button>-->
      </FormItem>
    </Form>
  </div>
</template>
<script>
  import {mapActions} from 'vuex'
  import user from "../../store/module/user";
  export default {
    data () {
      return {
        formItem: {
          name: '李琦',
          role: '1',
          id: 2015211166,
          classId: 2015211302,
          dep: '计算机学院', // 学院,
          password: '2015211166',
          userName: 'user_name',
          major: '计科'
        }
      }
    },

    created() {

    },

    methods: {
      ...mapActions([
        'submitUser'
      ]),
      handleSubmit() {
        const form = this.formItem
        const user = {
          name: form.name,
          role: form.role,
          id: form.id,
          classId: form.classId,
          department: form.dep, // 学院
          password: form.password,
          userName: form.userName,
          major: form.major
        }
        this.submitUser(user).then(

          res => {
            this.$Message.success("添加成功")
          }
        )
      }
    }
  }
</script>

<style scoped>
  .user-root {
    width: 500px;
    text-align: center;
  }
</style>

