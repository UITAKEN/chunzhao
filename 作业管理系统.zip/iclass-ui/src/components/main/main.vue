<template>
  <Layout style="height: 100%" class="main">
    <Layout>
      <Header class="header-con">
        <header-bar :collapsed="collapsed" @on-coll-change="handleCollapsedChange">
          <user :message-unread-count="unreadCount" :user-avator="userAvator"/>
        </header-bar>
      </Header>
      <Content class="main-content-con">
        <Layout class="main-layout-con">
          <Content class="content-wrapper">
            <!--<keep-alive :include="cacheList">-->
              <router-view></router-view>
            <!--</keep-alive>-->
            <ABackTop :height="100" :bottom="80" :right="50" container=".content-wrapper"></ABackTop>
          </Content>
        </Layout>
      </Content>
    </Layout>
  </Layout>
</template>
<script>
// import SideMenu from './components/side-menu'
import HeaderBar from './components/header-bar'
// import TagsNav from './components/tags-nav'
import User from './components/user'
import ABackTop from './components/a-back-top'

import './main.less'
export default {
  name: 'Main',
  components: {
    // SideMenu,
    HeaderBar,
    User,
    ABackTop
  },
  data () {
    return {
      collapsed: false,
      isFullscreen: false
    }
  },
  computed: {
    // ...mapGetters([
    //   'errorCount'
    // ]),
    cacheList () {
      return []
    }
  },
  methods: {
    handleCollapsedChange () {

    },
    unreadCount () {
      return 3
    },
    userAvator () {
      return "高勇"
    },

  },
  mounted () {
    // /**
    //  * @description 初始化设置面包屑导航和标签导航
    //  */
    // this.setTagNavList()
    // this.setHomeRoute(routers)
    // this.addTag({
    //   route: this.$store.state.app.homeRoute
    // })
    // this.setBreadCrumb(this.$route)
    // // 设置初始语言
    // this.setLocal(this.$i18n.locale)
    // // 如果当前打开页面不在标签栏中，跳到homeName页
    // if (!this.tagNavList.find(item => item.name === this.$route.name)) {
    //   this.$router.push({
    //     name: this.$config.homeName
    //   })
    // }
    // // 获取未读消息条数
    // this.getUnreadMessageCount()
  }
}
</script>
