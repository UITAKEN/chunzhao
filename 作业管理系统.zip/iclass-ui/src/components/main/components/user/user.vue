<template>
  <div class="user-avator-dropdown" style="display: flex; flex-direction: row">
        <Dropdown @on-click="handleClick">
          <Badge :dot="!!messageUnreadCount">
            <h2>{{this.name}}</h2>
          </Badge>
          <Icon :size="18" type="md-arrow-dropdown"></Icon>
          <DropdownMenu slot="list">
            <DropdownItem name="message" v-if = 'role === 1'>
              消息中心
              <Badge style="margin-left: 10px" :count="messageUnreadCount"></Badge>
            </DropdownItem>
            <DropdownItem name="logout">退出登录</DropdownItem>
          </DropdownMenu>
        </Dropdown>
      <!--</Col>-->
    <!--</Row>-->
  </div>
</template>

<script>
import './user.less'
import { mapActions } from 'vuex'
import { getUserInfo } from '@/libs/util'
import Cookies from 'js-cookie'
export default {
  name: 'User',
  props: {
    // userAvator: {
    //   type: String,
    //   default: 'https://i.loli.net/2017/08/21/599a521472424.jpg'
    // },
    messageUnreadCount: {
      type: Number,
      default: 0
    }
  },
  data () {
    return {
      name: '',
      role: '',
    }
  },
  methods: {
    ...mapActions([
      'handleLogOut'
    ]),
    logout () {
      this.handleLogOut().then(() => {
        Cookies.remove('count')
        Cookies.remove('id')
        Cookies.remove('isLogin')
        Cookies.remove('role')
        Cookies.remove('user')
        this.$router.push({
          name: 'login'
        })
      })
    },
    message () {
      this.$router.push({
        name: 'notice'
      })
    },

    profile() {
      this.$router.push({
        name: 'profile'
      })
    },
    handleClick (name) {
      switch (name) {
        case 'logout': this.logout()
          break
        case 'message': this.message()
          break
      }
    },
    setUserName () {
      let user = JSON.parse(getUserInfo());
      this.role = user.role
      this.name = user.name;
    }
  },
  created() {
    this.setUserName()
  }
}
</script>

<style>
  .user-avator-dropdown {
    /*float: right;*/
  }
</style>
