<template>
  <div class="header-bar">
    <div style="display: inline-block; margin-left: 50px">
      <h1>iClass作业管理系统</h1>
    </div>
    <user :message-unread-count= 'unread' style="margin-right: 50px"/>
  </div>
</template>
<script>
import User from '../user'
import './header-bar.less'
import {getCount} from "../../../../libs/util";
export default {
  name: 'HeaderBar',
  data() {
    return {
      unread: 0
    }
  },
  components: {
    User
  },
  props: {
    collapsed: Boolean
  },
  computed: {
    breadCrumbList () {
      // return this.$store.state.app.breadCrumbList
    }
  },
  methods: {
    handleCollpasedChange (state) {
      // this.$emit('on-coll-change', state)
    }
  },

  mounted() {
    this.unread = parseInt(getCount())
  }
}
</script>

<style scoped>
</style>
