<template>
  <div>
    <Card style="text-align: center">
      <h4 slot="title">
        作业列表
      </h4>
      <Table height="650" stripe border :columns="columns" :data="data"></Table>
    </Card>
  </div>
</template>

<script type="text/ecmascript-6">
  import {getWork} from "../../api/student";
  import {dateFtt, getUserId} from "../../libs/util";

  export default {
    name: '',
    data () {
      return {
        columns: [
          {
            title: '课程名称',
            key: 'courseName',
            align: 'center'
          },
          {
            title: '作业', // 昵称
            key: 'title',
            align: 'center'
          },
          {
            title: '创建日期',
            key: 'createDate',
            align: 'center'
          },
          {
            title: '截止日期',
            key: 'deadline',
            align: 'center'
          },
          {
            title: '任务描述',
            key: 'tasks',
            align: 'center'
          },
          {
            title: '分数比例',
            key: 'percent',
            align: 'center'
          },

        ],
        data: []
      }
    },

    mounted() {
      getWork(getUserId()).then(
        res => {
          // let courses = res.body
          this.data = res.body
          // courses.forEach(
          //   course => {
          //     let works = course.works
          //     works.forEach(
          //       work => {
          //         const time = new Date(work.deadLine)
          //         const deadline = dateFtt('yyyy-MM-dd', time)
          //         let tableMeta = {
          //           courseName: course.courseName,
          //           work: work.title,
          //           deadline: deadline,
          //           desc: work.tasks
          //         }
          //
          //         this.data.push(tableMeta)
          //       }
          //     )
          //   }
          // )
        }
      )
    }
  }
</script>

<style scoped>

</style>
