<template>
  <div>
    <Card style="text-align: center">
      <h3 slot="title">
        消息提醒
      </h3>
      <Table height="650" stripe border :columns="columns" :data="data"></Table>
    </Card>
  </div>
</template>

<script type="text/ecmascript-6">
  import {getMessage, readMessage} from "../../api/student";
  import {getUserId} from "../../libs/util";

  export default {
    name: '',
    data () {
      return {
        columns: [
          {
            title: '标题',
            key: 'title',
            align: 'center',
          },
          {
            title: '任务要求', // 昵称
            key: 'tasks',
            align: 'center',
          },
          {
            title: '通知',
            key: 'message',
            align: 'center'
          },
          {
            title: '截止日期',
            key: 'deadline',
            align: 'center'
          },
          {
            title: '操作',
            key: 'action',
            width: 150,
            align: 'center',
            render: (h, params) => {
              return h('div', [
                h('Button', {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.read(params.index)
                    }
                  }
                }, '已读'),
              ]);
            }
          }

        ],
        data: []
      }
    },
    methods: {
      read(index) {
        const row = this.data[index]
        readMessage(row.id).then(
          res => {
            if (res.success) {
              this.$Message.info("我知道了")
              this.data.splice(index, 1)
            }
        }
        )
      }
    },
    mounted() {
      getMessage(getUserId()).then(
        res => {
          this.data = res.body
        }
      )
    }
  }
</script>

<style scoped>

</style>
