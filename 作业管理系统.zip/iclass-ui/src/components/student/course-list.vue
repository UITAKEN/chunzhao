<template>
  <!--课程浏览页面-->
  <div>
    <Card style="text-align: center">
      <h4 slot="title">
        课程列表
      </h4>
      <Table stripe border :columns="columns" :data="data" height="600"></Table>
    </Card>
  </div>
</template>
<script>
  import {getCoursesByStu} from "../../api/student";
  import { mapState } from 'vuex'
  import {dateFtt} from '@/libs/util'
  import Cookies from 'js-cookie'
  export default {
    data () {
      return {
        columns: [
          {
            title: '课程名称',
            key: 'courseName',
            align: 'center'
          },
          {
            title: '创建日期', // 昵称
            key: 'createDate',
            align: 'center'
          },
          {
            title: '课程简介',
            key: 'intro',
            align: 'center'
          },
          {
            title: '教师',
            key: 'teacher',
            align: 'center'
          },

        ],
        data: []
      }
    },
    computed: {
      ...mapState([

      ])
    },
    created () {
      const stuId = Cookies.get('id')
      console.log(stuId)
      getCoursesByStu(stuId).then(
        res => {
          // res.body.forEach(item => {
          //   const time = new Date(item.createDate)
          //   item.createDate = dateFtt("yyyy-MM-dd", time)
          //   this.data.push(item)
          // })
          this.data = res.body

        }
      )
    }
  }
</script>
