<template>
  <!--创建小组页面-->
  <div class="course-root">
    <!--<Card style="text-align: center">-->
    <!--<p slot="title">创建课程</p>-->
    <Form :model="course" :label-width="80" inline style="display: flex; flex-direction: row">
      <FormItem label="课程" class="form-item">
        <Select v-model="formData.courseId" clearable :clearSingleSelect="remove">
          <Option v-for="item in courseList" :key="item.cid" :value="item.cid">{{ item.courseName }}</Option>
        </Select>
      </FormItem>

      <FormItem label="组长" class="form-item">
        <Input v-model="formData.leaderId" placeholder="组长学号，默认为小组创建者"></Input>
      </FormItem>

      <FormItem label="联系方式" class="form-item">
        <Input v-model="formData.contact" placeholder="Email/Phone/Tel"></Input>
      </FormItem>
    </Form>

    <Table stripe border :columns="columns" :data="table"
           @on-select="handleSelect"
           @on-row-dblclick = "handleClick"
           height="600" v-if="showTable"></Table>

    <Form inline style="margin-top: 20px">
      <FormItem>
        <Button type="primary" style="width: 80px;" large @click="handleSubmit">提交</Button>
      </FormItem>
    </Form>
    <!--</Card>-->
  </div>
</template>
<script>
  import { getUserId } from '@/libs/util'
  import {createGroup, getCoursesByStu, getStusByDep} from "../../api/student";
  export default {
    data () {
      return {
        formData: {
          contact: '13021131200',
          courseId: 'ff80818167e5935a0167e59523f00001',
          members: [ // 已选择的学生id列表
          ],
          leaderId: ''
        },
        showTable: true,
        course: {
          courseName: '',
          date: '',
          intro: '',
          teacherName: '肖丁',
        },
        courseList: [ // 课程列表
        ],
        // selection: [], // 已选的学生列表
        leaderName: '',
        columns: [
          {
            type: 'selection',
            align: 'center',
            width: 50
          },
          {
            title: '学号',
            key: 'sid',
            align: 'center',
          },
          {
            title: '班级', // 昵称
            key: 'classId',
            align: 'center'
          },
          {
            title: '姓名',
            key: 'name',
            align: 'center'
          },
          {
            title: '专业',
            key: 'major',
            align: 'center'
          },
          {
            title: '组长',
            key: 'action',
            align: 'center',
            render: (h, params) => {
              return h('div', [
                h('Button', {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.setLeader(params.index)
                    }
                  }
                }, '选择'),
              ]);
            }
          }
        ],
        table: [],
      }
    },

    methods: {
      cancel() {
        this.$Message.warning('操作已取消');
      },
      remove() {

      },
      handleSubmit() {
        console.log(this.formData)
        createGroup(this.formData).then(
          res => {
            console.log(res)
          }
        )
      },
      setLeader(index) {
        const leader = this.table[index]
        this.formData.leaderId = leader.sid
        console.log(this.leaderName)

      },
      cancelLeader(index) {
        this.formData.leaderId = ''
      },
      handleSelect(selection, row) { // selection: 已选项
        console.log(row.user.id)
        this.formData.members.push(row.user.id)
      },

      handleClick(index) {
        console.log(index)
      }
    },
    mounted() {
      const id = getUserId()
      getCoursesByStu(id).then(
        res => {
          this.courseList = res.body
        }
      )

      // 获取所有学生

      getStusByDep(id).then(
        res => {
          this.table = res.body
          this.table.forEach(
            item => {
              item.name = item.user.name
            }
          )
        }
      )
    }
  }
</script>

<style scoped>
  .course-root {
    /*width: 500px;*/
  }
  .form-item {
    text-align: center;
    display: inline-block;
    width: 300px;
  }
</style>

