<template>
  <div>

  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    name: '',

    mounted() {
      this.$Message.error('系统错误')
    }
  }
</script>

<style scoped>

</style>
