<template>
  <div>
    <Table :columns="columns"
           :data="rows"
           height="200"></Table>
  </div>
</template>
<script>
  export default {
    props: {
      rows: Array
    },
    data() {
      return {
        columns: [
          {
            title: '学号',
            key: 'sid',
            align: 'center'
          },
          {
            title: '班级', // 昵称
            key: 'classId',
            align: 'center'
          },
          {
            title: '姓名', // 昵称
            key: 'name',
            align: 'center'
          },
          {
            title: '专业',
            key: 'major',
            align: 'center'
          },
        ]
      }
    }
  };
</script>

<style scoped>
  .expand-row{
    margin-bottom: 16px;
  }
</style>
