<template>
  <!--课程浏览页面-->
  <div>
    <Card style="text-align: center">
      <h4 slot="title">
        分组列表
      </h4>
      <Table stripe border :columns="columns"
             :data="data"
             height="650"></Table>
    </Card>
  </div>
</template>
<script>
  import expandRow from './table-expand.vue'

  import {getCoursesByStu, getGroups} from "../../api/student"
  import { mapState } from 'vuex'
  import {dateFtt} from '@/libs/util'
  import Cookies from 'js-cookie'
  export default {
    data () {
      return {
        columns: [
          {
            type: 'expand',
            title: '组员',
            width: 80,
            align: 'center',
            render: (h, params) => {
              console.log('row', params.row)
              return h(expandRow, {
                props: {
                  rows: params.row.members
                }
              })
            }
          },
          {
            title: '组号',
            key: 'groupId',
            align: 'center'
          },
          {
            title: '组长', // 昵称
            key: 'leader',
            align: 'center'
          },
          {
            title: '人数', // 昵称
            key: 'count',
            align: 'center'
          },
          {
            title: '联系方式',
            key: 'tel',
            align: 'center'
          },

        ],
        data: []
      }
    },
    computed: {
      ...mapState([

      ])
    },
    created () {

    },
    mounted() {
      const stuId = Cookies.get('id')
      getGroups(stuId).then(
        res => {
          console.log(res)
          this.data = res.body
        }
      )
    }
  }
</script>
