<template>
  <!--创建作业页面-->
  <div class="task-root">
    <Form :model="formData" :label-width="80">
      <FormItem label="选择课程">
        <Select v-model="formData.courseId" style="width:200px">
          <Option v-for="item in courseList" :value="item.cid" :key="item.cid">{{ item.courseName }}</Option>
        </Select>
      </FormItem>
      <FormItem label="作业标题">
        <Input v-model="formData.title" placeholder="请输入作业标题"></Input>
      </FormItem>
      <FormItem label="作业要求">
        <Input v-model="formData.tasks" placeholder="作业要求" type="textarea" :autosize="{minRows: 2,maxRows: 5}"></Input>
      </FormItem>

      <FormItem label="成绩比例">
        <Slider class="slider" v-model="formData.percent" show-input :min="0" :max="100"></Slider>
      </FormItem>
      <FormItem label="截止日期">
        <DatePicker format="yyyy/MM/dd" v-model="formData.deadTime" type="date" placeholder="请选择截止日期" style="width: 200px"></DatePicker>
      </FormItem>
      <FormItem>
        <Button type="primary" @click="handleSubmit">提交</Button>
      </FormItem>
    </Form>
    <!--</Card>-->
  </div>
</template>
<script>

  import {createTask, getCourseByTeacherId} from "../../api/teacher";

  export default {
    name: 'task-form',
    data () {
      return {
        formData: {
          title: 'iClass',
          tasks: '设计并实现一个作业管理系统',
          percent: 40,
          deadTime: '',
          courseId: 'ff80818167e5935a0167e59523f00001',
        },
        courseList: [

        ]

      }
    },
    methods: {
      handleSubmit () {
        this.formData.deadTime = this.formData.deadTime.toLocaleDateString() // 日期转换为当地时间
        createTask(this.formData).then(
          res => {
            if (res.success)
              this.$Message.success("添加成功")
          }
        )

      }
    },

    mounted() {
      getCourseByTeacherId().then(
        res => {
          if (!res.success) {
            this.$Message.error('系统错误,请稍后再试');
            return
          }
          console.log(res.body)
          this.courseList = res.body
        }
      )
    }
  }
</script>

<style scoped>
  .task-root {
    width: 500px;
    height: 600px;
  }

  .slider {
    width: 400px;
  }
</style>

