<!--查看已经分配的学生名单列表-->
<template>
  <div id="content">
    <div style="display: flex; justify-content: flex-start; align-items: center; margin-bottom: 5px">
      <h4 style="margin-right: 10px">课程选择</h4>
      <Select v-model="courseId" style="width:300px;">
        <Option style="text-align: center" v-for="item in courseList" :value="item.cid" :key="item.cid">{{ item.courseName }}</Option>
      </Select>

      <Button style="margin-left: 10px" type="primary" @click="handleSubmit">查询</Button>
    </div>
    <!--<div >-->
    <Card style="text-align: center">
      <!--姓名，学号，班级，作业成绩，平时成绩-->
      <Table stripe border :columns="columns" :data="this.table" :height="650"></Table>
    </Card>
  </div>
</template>
<script>
  import {getAllCourses, getCourseByTeacherId} from "../../api/teacher";
  import {mapActions} from 'vuex'
  export default {
    data () {
      return {
        columns: [
          {
            title: '学号',
            key: 'id',
            align: 'center'
          },
          {
            title: '姓名', // 昵称
            key: 'name',
            align: 'center'
          },
          {
            title: '班级', // 昵称
            key: 'classId',
            align: 'center'
          },
          {
            title: '总评成绩',
            key: 'score',
            align: 'center'
          }

        ],
        data: {
          courses: [],
          tableData: []
        },

        table: [],
        courseList: [],
        courseId: '',
      }
    },
    methods: {
      ...mapActions([
        'getStusByCourse'
      ]),
      handleSubmit () {
        this.getStusByCourse(this.courseId).then(
          res => {
            this.table = res.body
          }
        )
      }
    },
    mounted() {
      getAllCourses().then(
        res => {
          this.courseList = res.body
        }
      )
      // getCourseByTeacherId().then(
      //   res => {
      //     this.data.courses = res.body;
      //   }
      // )
    }
  }
</script>

<style scoped>
  #content {
    overflow: auto;
  }
</style>

