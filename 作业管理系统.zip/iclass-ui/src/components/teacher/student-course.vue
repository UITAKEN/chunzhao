<!--为学生分配课程-->
<template>
  <div>
    <Card style="text-align: center;">
      <h3 slot="title">
        导入学生名单
      </h3>
          <div style="display: flex; justify-content: flex-start; align-items: center; margin-bottom: 5px">
            <p style="margin-right: 10px">课程选择</p>
            <Select v-model="data.course" style="width:300px;">
              <Option v-for="item in courses" :key="item.cid" :value="item.cid">{{ item.courseName }}</Option>
            </Select>
          </div>
      <Table stripe border :columns="columns" :data="data.tableData" height="600"></Table>

      <div style="display: flex; flex-direction: row; margin-top: 10px">
        <Upload action="http://localhost:8080/teacher/import"
                name="excel"
                :on-success="handleSuccess"
                :on-error="handleError"
                :with-credentials=true
                style="display: inline;">
          <Button type="primary"
                  icon="ios-cloud-upload-outline"
                  style="height: 40px;">
            导入Excel文件</Button>
        </Upload>

        <Button style="height: 40px;
               margin-left: 10px"
                type="info" @click="handleSubmit"> &nbsp; 保存 &nbsp; </Button>
      </div>

    </Card>
  </div>
</template>
<script>
  import {getAllCourses, getTableData, saveStuList} from "../../api/teacher";


  import { Message } from 'iview'
  import {mapActions} from 'vuex'
  import axios from 'axios'
  import qs from 'qs'

  export default {
    data () {
      return {
        ruleInline: {

        },
        courses: [],
        columns: [
          {
            title: '学号',
            key: 'id',
            align: 'center'
          },
          {
            title: '姓名', // 昵称
            key: 'name',
            align: 'center'
          },
          {
            title: '班级', // 昵称
            key: 'classId',
            align: 'center'
          },
          {
            title: '学院', // 昵称
            key: 'department',
            align: 'center'
          },
          {
            title: '专业', // 昵称
            key: 'major',
            align: 'center'
          },
          {
            title: '操作',
            key: 'action',
            width: 150,
            align: 'center',
            render: (h, params) => {
              return h('div', [
                h('Button', {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.remove(params.index)
                    }
                  }
                }, 'Delete')
              ]);
            },
          }
        ],
        data: {
          tableData: [],
          course: '',
          upload: false
        }
      }
    },
    created () {
      // 发送请求，获取数据
    },
    methods: {
      ...mapActions([
        'submitStuList'
      ]),
      remove (index) {
        this.data.tableData.splice(index, 1);
      },
      handleSubmit () {
        const url = 'http://localhost:8080/teacher/save'
        let ids = [];
        this.data.tableData.forEach(
          item => {
            ids.push(item.id)
          }
        )
        axios({
          url:url,
          method:'post',
          data:qs.stringify({
            'stuList': ids.toString(),
            'courseId': this.data.course
          }),
          headers: {
            // 'Content-Type': 'application/json'
          }
        }).then(
          res => {
            this.$Message.success("保存成功")
            console.log(res)
          }
        )
      },
      handleSuccess (res) {
        // console.log(res)
        Message.success("上传成功")
        this.data.upload = true
        this.data.tableData = res.body
      },
      handleError(err) {
        console.log(err)
      }
    },
    mounted() {
      getAllCourses().then(
        res => {
          this.courses = res.body;
        }
      )
      // if (this.data.upload) {
        getTableData().then(
          res => {
            this.data.tableData = res.body
          }
        )
      // }
    }
  }
</script>

