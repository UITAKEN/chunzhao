<template>
  <div id="group-root">
    <!--<Card style="text-align: center; width: 600px">-->
    <h2>分组设置</h2>
      <Form :model="group" :label-width="100">
        <FormItem label="小组序号前缀">
          <Input v-model="group.preSerial" placeholder="请输入小组序号前缀：形如(年份-班级)，例：2018-02)"></Input>
        </FormItem>
        <FormItem label="最少人数">
          <Input v-model="group.minMembers" placeholder="最少人数"></Input>
        </FormItem>
        <FormItem label="最大人数">
          <Input v-model="group.maxMembers" placeholder="最大人数"></Input>
        </FormItem>
        <FormItem style="text-align: left">
          <Button type="primary" @click="handleSubmit">提交</Button>
        </FormItem>
      </Form>
    <!--</Card>-->
  </div>
</template>

<script>
  import { addGroupConfig } from "../../api/teacher";

  export default {
    name: "group-form",
    data() {
      return {
        group: {
          preSerial: '2018-03',
          minMembers: '2',
          maxMembers: '5'
        }
      }
    },
    methods: {
      handleSubmit() {
        addGroupConfig(this.group).then(
          res => {
            console.log(res)
            this.$Message.success('添加成功');
          }
        )
      }
    }
  }
</script>

<style scoped>
  #group-root {
    /*display: flex;*/
    /*justify-content: center;*/
    /*align-items: center;*/
    width: 500px;
    height: 600px;
    text-align: center;
  }
</style>