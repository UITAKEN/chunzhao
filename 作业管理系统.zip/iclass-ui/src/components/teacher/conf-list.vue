<template>
  <div>
    <Card style="text-align: center">
      <h4 slot="title">
        配置列表
      </h4>
      <Table stripe border :columns="columns" :data="table"></Table>
    </Card>
  </div>
</template>

<script>
  import {delConf, getAllConfs} from "../../api/teacher";

  export default {
    name: "conf-list",
    data() {
      return {
        columns: [
          {
            title: '小组序号',
            key: 'preSerial',
            align: 'center'
          },
          {
            title: '最少人数', // 昵称
            key: 'minMembers',
            align: 'center'
          },
          {
            title: '最大人数',
            key: 'maxMembers',
            align: 'center'
          },
          {
            title: '操作',
            key: 'action',
            width: 150,
            align: 'center',
            render: (h, params) => {
              return h('div', [
                h('Button', {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.remove(params.index)
                    }
                  }
                }, '删除')
              ]);
            }
          }

        ],
        table: []
      }
    },
    methods: {
      remove(index) {
        const id = this.table[index].preSerial
        delConf(id).then(
          res => {
            if (res.success) {
              this.table.splice(index, 1);
              this.$Message.success(res.body)
            }
          }
        )
      }
    },
    mounted() {
      getAllConfs().then(
        res => {
          this.table = res.body;
        }
      )
    }
  }
</script>

<style scoped>

</style>