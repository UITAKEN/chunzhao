<template>
  <div>
    <Card style="text-align: center">
      <h4 slot="title">
        作业列表
      </h4>
      <Table stripe border :columns="columns" :data="table" height="650"></Table>
    </Card>
  </div>
</template>

<script>
  import {changeTaskPercent, getCourseByTeacherId} from "../../api/teacher";
  import {dateFtt} from "../../libs/util";

  export default {
    name: "task-list",
    data () {
      return {
        columns: [
          {
            title: '作业标题', // 昵称
            key: 'title',
            align: 'center'
          },
          {
            title: '课程名称',
            key: 'courseName',
            align: 'center'
          },
          {
            title: '创建日期', // 昵称
            key: 'createDate',
            align: 'center'
          },
          {
            title: '截止日期',
            key: 'deadline',
            align: 'center'
          },
          {
            title: '作业描述',
            key: 'tasks',
            align: 'center'
          },
          {
            title: '分数比例',
            key: 'percent',
            align: 'center'
          },
          {
            title: '操作',
            key: 'action',
            width: 150,
            align: 'center',
            render: (h, params) => {
              return h('div', [
                h('Button', {
                  props: {
                    type: 'info',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.changePercent(params.index)
                    }
                  }
                }, '修改比例')
              ]);
            }
          }

        ],
        table: [],
        newPercent: '',
        task: '' // 待修改分数比例的作业
      }
    },
    methods: {
      changePercent(index) {
        this.$Modal.confirm({
          render: (h) => {
            return h('Input', {
              props: {
                value: this.newPercent,
                autofocus: true,
                placeholder: '请输入新的分数比例'
              },
              on: {
                input: (val) => {
                  this.newPercent = val;
                }
              }
            })
          },
          onOk: () => {
            this.task = this.table[index]
            // 调用api保存新的数据
            changeTaskPercent(this.task.id, this.newPercent).then(
              res => {
                const task = res.body
                this.table[index].percent = task.percent + '%'
                this.$Message.info('修改成功')
              }
            )
          },
          onCancel: () => {
            this.task = ''
            this.$Message.info('取消修改');
          },
        })
      }
    },
    mounted() {
      getCourseByTeacherId().then(
        res => {
          const courses = res.body
          courses.forEach(
            course => {
              const works = course.works
              works.forEach(
                work => {
                  const createTime = new Date(work.createDate)
                  const deadline = new Date(work.deadline)
                  let tableMeta = {
                    id: work.id,
                    title: work.title,
                    courseName: course.courseName,
                    createDate: dateFtt('yyyy-MM-dd',createTime),
                    tasks: work.tasks,
                    deadline: dateFtt('yyyy-MM-dd', deadline),
                    percent: work.percent + '%'
                  }

                  this.table.push(tableMeta)
                }
              )
            }
          )
        }
      )
    }
  }
</script>

<style scoped>

</style>