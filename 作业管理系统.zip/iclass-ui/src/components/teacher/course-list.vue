<template>
  <!--课程浏览页面-->
  <div>
    <Card style="text-align: center">
      <h4 slot="title">
        课程列表
      </h4>
      <Table stripe border :columns="columns" :data="table"></Table>
    </Card>
  </div>
</template>
<script>
  import {getAllCourses, getCourseByTeacherId} from "../../api/teacher";
  import { dateFtt } from "../../libs/util";

  export default {
    data () {
      return {
        columns: [
          {
            title: '课程名称',
            key: 'courseName',
            align: 'center'
          },
          {
            title: '创建日期', // 昵称
            key: 'createDate',
            align: 'center'
          },
          {
            title: '课程简介',
            key: 'intro',
            align: 'center'
          },
          {
            title: '教师',
            key: 'teacher',
            align: 'center'
          }

        ],
        table: []
      }
    },
    methods: {

    },
    mounted() {
      getCourseByTeacherId().then(
        res => {
          this.table = res.body
          // this.table.forEach(item => {
          //   const time = new Date(item.createDate)
          //   item.createDate = dateFtt("yyyy-MM-dd", time)
          // })
        }
      )
    },
    created () {
      // 发送请求，获取数据
    }
  }
</script>
