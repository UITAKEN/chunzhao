<template>
  <!--所有小组列表界面-->
  <div>
    <Card style="text-align: center">
      <h4 slot="title">
        分组列表
      </h4>
      <Table stripe border :columns="columns" :data="table" height="650"></Table>
    </Card>
  </div>
</template>

<script>
  import {getAllGroups} from "../../api/teacher";

  export default {
    name: "group-list",
    data() {
      return {
        columns: [
          {
            title: '小组序号',
            key: 'id',
            align: 'center'
          },
          {
            title: '小组人数',
            key: 'memberNum',
            align: 'center'
          },
          {
            title: '组长',
            key: 'leaderName',
            align: 'center'
          },
          {
            title: 'Tel',
            key: 'tel',
            align: 'center'
          },

        ],
        table: []
      }
    },
    methods: {
      // remove(index) {
      //   const id = this.table[index].preSerial
      // }
    },
    mounted() {
      getAllGroups().then(
        res => {
          this.table = res.body
        }
      )
    }
  }
</script>

<style scoped>

</style>