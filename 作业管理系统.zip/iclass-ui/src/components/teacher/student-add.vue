<template>
  <div id="content">
    <div style="display: flex; justify-content: flex-start; align-items: center; margin-bottom: 5px">
      <h4 style="margin-right: 10px">选择课程</h4>
      <Select v-model="courseId" style="width:300px;">
        <Option style="text-align: center" v-for="item in courseList" :value="item.cid" :key="item.cid">{{ item.courseName }}</Option>
      </Select>
    </div>
    <Card style="text-align: center">
      <Table stripe border :columns="columns" :data="this.table"
             @on-select="handleSelect"
             :height="600"></Table>
    </Card>

    <Button style="margin-left: 10px; margin-top: 10px" type="primary" @click="handleSubmit">提交</Button>
  </div>
</template>
<script>
  import {getAllCourses, getAllStus, getCourseByTeacherId, saveStudents} from "../../api/teacher";
  import {mapActions} from 'vuex'
  export default {
    data () {
      return {
        columns: [
          {
            type: 'selection',
            align: 'center',
            width: 50
          },
          {
            title: '学号',
            key: 'id',
            align: 'center'
          },
          {
            title: '姓名', // 昵称
            key: 'name',
            align: 'center'
          },
          {
            title: '班级', // 昵称
            key: 'classId',
            align: 'center'
          },
          {
            title: '学院', // 昵称
            key: 'department',
            align: 'center'
          },
          {
            title: '专业', // 昵称
            key: 'major',
            align: 'center'
          },

        ],

        table: [],
        courseList: [],
        courseId: '',
        students: [],
      }
    },
    methods: {
      ...mapActions([
        'getStusByCourse'
      ]),
      handleSelect(selection, row) { // selection: 已选项
        console.log(row)
        this.students.push(row.id)
      },
      handleSubmit () {
        saveStudents(this.courseId, this.students).then(
          res => {
            console.log(res)
            this.$Message.success("保存成功")
          }
        )
      }
    },
    mounted() {
      getAllCourses().then(
        res => {
          this.courseList = res.body
        }
      )
      getAllStus().then(
        res => {
          this.table = res.body
        }
      )
    }
  }
</script>

<style scoped>
  #content {
    overflow: auto;
  }
</style>

