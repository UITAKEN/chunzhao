<template>
  <!--创建课程页面-->
  <div class="course-root">
    <!--<Card style="text-align: center">-->
      <!--<p slot="title">创建课程</p>-->
      <Form :model="course" :label-width="80">
        <FormItem label="课程名称">
          <Input v-model="course.courseName" placeholder="请输入课程名称"></Input>
        </FormItem>
        <FormItem label="创建日期" v-show="false">
          <Input v-model="course.createDate" placeholder="创建日期"></Input>
          <!--<DatePicker v-model="course.createDate" type="date" placeholder="Select date" style="width: 200px"></DatePicker>-->
        </FormItem>
        <FormItem label="课程简介">
          <Input v-model="course.intro" placeholder="请输入学院..."></Input>
        </FormItem>
        <FormItem label="教师名称">
          <Input v-model="course.teacherName" placeholder="请输入课程名称"></Input>
        </FormItem>

        <FormItem label="学分">
          <Slider class="slider" v-model="course.score" show-input :min="1" :max="6"></Slider>
        </FormItem>
        <FormItem label="点名次数">
          <Slider class="slider" v-model="course.allCallNumber" show-input :min="1" :max="5"></Slider>
        </FormItem>
        <FormItem label="点名分数">
          <Slider class="slider" v-model="course.onCallScore" show-input :min="0" :max="40"></Slider>
        </FormItem>
        <FormItem>
          <Button type="primary" @click="handleSubmit">提交</Button>
          <Button type="info" style="margin-left: 8px">取消</Button>
        </FormItem>
      </Form>
    <!--</Card>-->
  </div>
</template>
<script>
  import { createCourse } from "../../api/teacher";
  import { getUserInfo } from "../../libs/util";

  export default {
    data () {
      return {
        course: {
          courseName: '算法设计与分析',
          intro: '软件工程',
          teacherName: '萧鼎',
          // createDate: this.getCurrentDate(),
          score: 1,
          allCallNumber: 1, // 点名次数
          onCallScore: 1, // 一次点名得分
          // teacherId: getUserInfo().id
        },
      }
    },
    methods: {

      handleSubmit () {
        console.log(this.course)
        createCourse(this.course).then(
          res => {
            console.log(res)
          }
        )
      }
    },

    mounted() {
    }
  }
</script>

<style scoped>
  .course-root {
    width: 500px;
    height: 600px;
  }

  .slider {
    width: 400px;
  }
</style>

