import Vue from 'vue'
import Vuex from 'vuex'

import user from './module/user'
import stu from './module/student'
import admin from './module/admin'
import teacher from './module/teacher'

Vue.use(Vuex);

export default new Vuex.Store({
  // strict: true,
  state: {
    //
  },
  mutations: {
    //
  },
  getters: {
    //
  },
  actions: {
    //
  },
  modules: {
    user,
    stu,
    admin,
    teacher
  }
})
