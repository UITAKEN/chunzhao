import { login, logout, getUserInfo } from '@/api/user'
import {
  setLoginStatus,
  getLoginStatus,
  setUserInfo,
  setUserRole,
  setUserId,
  getUserId,
} from '@/libs/util'
const state = {
  user: {
    id: getUserId(),
    name: "",
    isFirstLogin: '',
    role: ''
  },
  isLogin: getLoginStatus() // 用户登陆状态标志位，false: 未登录, true: 已经登陆
};
const getters = {
  user(state) {
    return state.user
  },

  isLogin(state) {
    return state.isLogin
  }
};
const mutations = {
  // 存储用户信息
  setUser (state, user) {
    state.user.id = user.id
    state.user.name = user.name
    state.user.isFirstLogin = user.isFirstLogin
    state.user.role = user.userRole.roleName
    setUserInfo(user) // 将已经登陆的用户信息存储在cookie中
    setUserRole(user.userRole.roleName)
    setUserId(user.id)
  },
  setLogin (state, login) {
    state.isLogin = login
    setLoginStatus(login)
  }
  // hello: (state, payload) => {
  //   console.log(payload)
  // }
};
// 提交mutations, 不直接改变状态
// 执行异步操作
const actions = {
  // 登录
  handleLogin (context, {id, password}) {
    // userName = userName.trim()
    return new Promise((resolve, reject) => {
      login({
        id,
        password
      }).then(res => {
        console.log('res:', res)
        const body = res.body
        context.commit('setUser', body)
        context.commit('setLogin', true)
        resolve(res)
      }).catch(err => {
        // console.log('user.js log:', err)
        console.log('user.js log:', err)
        reject(err)
      })
    })
  },
  // 获取用户相关信息
  getUserInfo () {
    // console.log(id)
    return new Promise((resolve, reject) => {
      getUserInfo(2014211166).then(res => {
        console.log('getUserInfo',res)
        resolve(res)
      }).catch(err => {
        reject(err)
      })
    })
  },

  // 退出登录
  handleLogOut ({ state, commit }) {
    return new Promise((resolve, reject) => {
      logout().then((res) => {
        console.log(res)
        // commit('setUserInfo', '')
        // commit('setUserRole', '')
        // commit('setLoginStatus', false)
        setLoginStatus(false)
        setUserInfo('')
        setUserRole('')
        resolve()
      }).catch(err => {
        reject(err)
      })
    })
  },
}

export default {
  getters,
  mutations,
  actions,
  state
}
