import {addUser} from "@/api/user";

const state = {

};
const getters = {

};
const mutations = {

};
// 提交mutations, 不直接改变状态
// 执行异步操作
const actions = {
  submitUser(context, {name, role, id, classId, department, password, userName, major}) {
    return new Promise((resolve, reject) => {
      addUser({
        name,
        role,
        id,
        classId,
        department,
        password,
        userName,
        major
      }).then(res => {
        resolve(res)
      }).catch(err => {
        reject(err)
      })
    })
  }
}

export default {
  getters,
  mutations,
  actions,
  state
}
