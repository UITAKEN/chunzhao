import { getStudentInfo } from '@/api/student'
// import { setToken, getToken } from '@/libs/util'
const state = {
  student: {

  }
};
const getters = {
  student(state) {
    return state.student
  }
};
const mutations = {
  setStuent (state, student) {
    state.student = student
  },
  // hello: (state, payload) => {
  //   console.log(payload)
  // }
};
// 提交mutations, 不直接改变状态
// 执行异步操作
const actions = {
  // 获取用户相关信息
  getStudent (context, id) {
    // console.log(id)
    return new Promise((resolve, reject) => {
      getStudentInfo(id).then(res => {
        context.commit('setStudent', res.body)
        resolve(res)
      }).catch(err => {
        reject(err)
      })
    })
  },
}

export default {
  getters,
  mutations,
  actions,
  state
}
