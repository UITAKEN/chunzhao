import { saveStuList, getStusByCourse } from "@/api/teacher";

const state = {

};
const getters = {

};
const mutations = {

};
// 提交mutations, 不直接改变状态
// 执行异步操作
const actions = {
  submitStuList(context, {stuList}) {
    return new Promise((resolve, reject) => {
      saveStuList({
        stuList
      }).then(res => {
        resolve(res)
      }).catch(err => {
        reject(err)
      })
    })
  },
  getStusByCourse(context, cid) {
    return new Promise(((resolve, reject) => {
      getStusByCourse(cid).then(res => {
        resolve(res)
      }).catch(err => {
        reject(err)
      })
    }))
  }
}

export default {
  getters,
  mutations,
  actions,
  state
}
