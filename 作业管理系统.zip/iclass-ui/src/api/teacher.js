import axios from '@/libs/api.request'
import {getUserId, getUserInfo} from "../libs/util";

export const getTeacherInfo = (id) => {
  const full = '/teacher/' + id.toString();
  return axios.request({
    url: full,
    method: 'get'
  })
}


export const createCourse = (course) => {
  return axios.request({
    url: '/course/add',
    data: course,
    method: 'post'
  })
}


export const getCoursesByTeacherId = () => {
  const user = getUserInfo()
  const id = user.id
  console.log(id)
  return axios.request({
    url: '/teacher/courses',
    data: id,
    method: 'get'
  })
}

/**
 * 获取该老师的所有课程
 * @returns {never}
 */
export const getAllCourses = () => {
  const url = '/teacher/courses?id=' + getUserId();
  return axios.request({
    url: url,
    method: 'get'
  })
}

/**
 * 根据课程id获取单个课程信息
 * @returns {never}
 */
export const getCourse = ({id}) => {
  const data = {
    id
  }
  return axios.request({
    url: '/teacher/courses',
    data,
    method: 'get'
  })
}

export const getTableData = () => {
  return axios.request({
    url: '/teacher/excel',
    method: 'get'
  })
}

/**
 * 保存某一课程的学生列表
 * @param list
 */
export const saveStuList = ({stuList}) => {
  const data = {
    stuList
  }
  const request = axios.request({
    url: '/teacher/save',
    method: 'post',
    data
  })
  console.log("request", request)
  return request
}

/**
 * 获取某一课程的学生列表
 * @param cid 课程id
 * @returns {never}
 */
export const getStusByCourse = (cid) => {
  const url = '/course/stus/' + cid.toString()
  return axios.request({
    url: url,
    method: 'get',
  })
}

export const addGroupConfig = (config) => {
  return axios.request({
    url: '/groupConf/add',
    method: 'post',
    data: config
  })
}

export const getAllConfs = () => {
  const url = '/groupConf/configs/'
  return axios.request({
    url: url,
    method: 'get',
  })
}

/**
 * 根据id删除分组配置
 * @param id 配置id
 */
export const delConf = (id) => {
  const url = '/groupConf/'+id.toString()
  return axios.request({
    url: url,
    method: 'delete'
  })
}

export const getAllGroups = () => {
  const url = '/group/groups'
  return axios.request({
    url: url,
    method: 'get',
  })
}


export const getCourseByTeacherId = () => {
  const id = getUserId();
  const url = '/teacher/courses?id=' + id.toString()
  return axios.request({
    url: url,
    method: 'get'
  })
}

/**
 * 修改作业占比
 * @param id 作业id
 * @param percent 分数比例
 * @returns {never}
 */
export const changeTaskPercent = (id, percent) => {
  return axios.request({
    url: '/work/modify',
    data: {
      id: id,
      percent: percent
    },
    method: 'post'
  })
}

export const createTask = (task) => {
  return axios.request({
    url: '/work/add',
    data:task,
    method: 'post'
  })
}

export const getAllStus = () => {
  return axios.request({
    url: '/stu/all',
    method: 'get'
  })
}

/**
 * 为某一课程添加学生列表
 * @param courseId
 * @param stuList
 * @returns {never}
 */
export const saveStudents = (courseId, stuList) => {
  // stuList = JSON.stringify(stuList)
  return axios.request({
    url: '/teacher/saveStus',
    data: {
      courseId: courseId,
      stuList: stuList.toString()
    },
    method: 'post'
  })
}