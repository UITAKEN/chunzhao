import axios from '@/libs/api.request'

/**
 * 或许某个教师所创建的课程
 * @returns {never}
 */
export const getCourse = () => {
  return axios.request({
    url: '/course',
    params: {
      id
    },
    method: 'get'
  })
}
