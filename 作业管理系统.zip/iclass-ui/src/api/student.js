import axios from '@/libs/api.request'

export const getStudentInfo = (id) => {
  console.log('id', id)
  const full = '/stu/' + id.toString();
  console.log(full)
  return axios.request({
    url: full,
    method: 'get'
  })
}

/**
 * 根据学生Id获取该学生的课程
 * @param stuId
 * @returns {never}
 */
export const getCoursesByStu = (stuId) => {
  const full = '/stu/courses/' + stuId.toString();
  return axios.request({
    url: full,
    method: 'get'
  })
}


export const getStusByDep = (id) => {
  const url = '/stu/dep/' + id.toString()
  return axios.request({
    url: url,
    method: 'get'
  })
}

/**
 * 创建小组
 * @param group
 * @returns {never}
 */
export const createGroup = (group) => {
  const json = {
    json: JSON.stringify(group)
  }

  console.log('json', json)
  const url = '/group/add'
  return axios.request({
    url: url,
    method: 'post',
    data: json
  })
}

/**
 * 获取所有的作业信息
 */
export const  getWork = (id) => {
  const url = '/work/works/' + id.toString()
  return axios.request({
    url: url,
    method: 'get',
  })
}

export const  getGroups = (id) => {
  const url = '/stu/groups/' + id.toString()
  return axios.request({
    url: url,
    method: 'get',
  })
}

/**
 *
 * @param id: 学生id
 * @returns {never}
 */
export const  getMessage = (id) => {
  const url = '/stu/message/' + id.toString()
  return axios.request({
    url: url,
    method: 'get',
  })
}

/**
 *
 * @param id 消息id
 * @returns {never}
 */
export const  readMessage = (id) => {
  const url = '/message/read/' + id.toString()
  return axios.request({
    url: url,
    method: 'delete',
  })
}