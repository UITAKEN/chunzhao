import axios from '@/libs/api.request'
import user from "../store/module/user";

export const login = ({ id, password }) => {
  const data = {
    id,
    password
  }
  return axios.request({
    url: '/login',
    data,
    method: 'post'
  })
}

/**
 * 根据角色添加不同的用户,角色不同添加用户时对应的后端接口也不同
 * @param name
 * @param role
 * @param id
 * @param classId
 * @param department
 * @param password
 * @param userName
 * @param major
 * @returns {never}
 */
export const addUser = ({name, role, id, classId, department, password, userName, major}) => {
  const data = {
    name,
    role,
    id,
    classId,
    department,
    password,
    userName,
    major
  }
  return axios.request({
    url: '/admin/addUser',
    data: data,
    method: 'post'
  })
}

export const modifyPassword = (id, password) => {
  return axios.request({
    url: '/user/password',
    data: {
      id: id,
      password: password
    },
    method: 'post'
  })
}

/**
 * 删除用户
 * @param id 用户id
 * @returns {never}
 */
export const delUser = (id)  => {
  console.log("user id", id)
  return axios.request({
    url: '/user/delete',
    data: id,
    method: 'delete'
  })
}

// export const getUserInfo = (token) => {
export const getUserInfo = (id) => {
  console.log('id', id)
  return axios.request({
    url: '/user/id',
    params: {
      id
    },
    method: 'get'
  })
}

/**
 * 从cookie获取JsessionId
 * @param cookie
 * @returns {never}
 */
export const logout = () => {
  return axios.request({
    url: 'logout',
    method: 'post'
  })
}
