import axios from '@/libs/api.request'


export const getAllUsers = () => {
  return axios.request({
    url: '/user/allUsers',
    method: 'get'
  })
}

export const getExcelData = () => {
  return axios.request({
    url: '/excel',
    method: 'get'
  })
}

export const saveExcelData = () => {
  return axios.request({
    url: '/save',
    method: 'get'
  })
}
