import axios from '@/libs/api.request'

// 老师获取所有学生的数据
export const getStudentData = (id) => {
  let stuId = id;
  let fullUrl = '/stu/'+ stuId
  debugger
  return axios.request({
    url: fullUrl,
    method: 'get'
  })
}

// 管理员获取所有用户数据
export const getUserData = () => {
  return axios.request({
    url: '/user/all',
    method: 'get'
  })
}

export const getDragList = () => {
  return axios.request({
    url: 'get_drag_list',
    method: 'get'
  })
}

export const errorReq = () => {
  return axios.request({
    url: 'error_url',
    method: 'post'
  })
}

export const saveErrorLogger = info => {
  return axios.request({
    url: 'save_error_logger',
    data: info,
    method: 'post'
  })
}

export const uploadImg = formData => {
  return axios.request({
    url: 'image/upload',
    data: formData
  })
}
