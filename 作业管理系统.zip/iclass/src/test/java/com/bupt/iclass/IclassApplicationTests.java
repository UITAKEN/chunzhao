package com.bupt.iclass;

import com.bupt.iclass.model.User;
// import com.bupt.iclass.repository.RoleAuthRepository;
import com.bupt.iclass.repository.UserRepository;
import com.bupt.iclass.util.Md5Encoder;
import com.bupt.iclass.util.Util;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = IclassApplication.class)
@Slf4j
public class IclassApplicationTests {

    @Autowired
    UserRepository userRepository;
    @Autowired
    // RoleAuthRepository repository;
    @Test
    public void contextLoads() {
    }
    @Test
    public void getAllUsers() {
        // List<User> users = userRepository.findUserName();
        // log.info(users.toString());
        // System.out.println(users.toString());
        // System.out.println("hello world.");
        // log.info("hello world");
    }

    @Test
    public void test() {
        String encode = Md5Encoder.encode("2010111000");
        System.out.println(encode);
    }

}
