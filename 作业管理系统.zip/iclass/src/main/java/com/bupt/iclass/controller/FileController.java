package com.bupt.iclass.controller;

import com.bupt.iclass.model.Response;
import com.bupt.iclass.model.User;
import com.bupt.iclass.model.UserX;
import com.bupt.iclass.service.UserService;
import com.bupt.iclass.util.Util;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

/**
 * 负责文件上传及下载功能
 */
@Api(description = "文件处理接口")
@RestController
@Slf4j
@CrossOrigin
public class FileController {


    @Autowired
    UserService userService;
    /**
     * 从Excel导入数据并在页面上显示，但是还未保存 注意：Excel第一行为表格标题
     *
     * @param file
     * @return
     */
    @RequestMapping("/upload")
    @ApiOperation("上传Excel文件并将文件记录信息返回到页面")
    public Response importUsers(@RequestParam("excel") MultipartFile file, HttpServletRequest request) {
        /**
         * 文件上传
         */
        if (file.isEmpty()) {
            return new Response(false, "文件为空");
        }
        // 服务器端保存的文件路径
        String serverFilePath;
        try {
            byte[] bytes = file.getBytes();
            String realPath = request.getSession().getServletContext().getRealPath("");
            log.info(realPath); // 输出文件路径
            Path path = Paths.get(realPath + file.getOriginalFilename()); // 文件名
            serverFilePath = path.toString();
            System.out.println(path.toString());
            Files.write(path, bytes);
        } catch (IOException e) {
            e.printStackTrace();
            return new Response(false, "上传失败");
        }

        try {
            // 使用HttpSession保存从Excel中读出的数据
            List<User> users = Util.importExcel(serverFilePath, 1, 1, User.class);
            HttpSession session = request.getSession();
            session.setAttribute("excel", users);
            return new Response(users, true);
        } catch (Exception e) {
            return new Response(false, "导入失败");
        }
    }

    @GetMapping("/excel")
    public Response getExcelData(HttpServletRequest request) {
        HttpSession session = request.getSession();
        Object excel = session.getAttribute("excel");
        return Response.success(excel);
    }


    @GetMapping("/save")
    public Response saveExcelData(HttpServletRequest request) {
        HttpSession session = request.getSession();
        Object excel = session.getAttribute("excel");
        List<User> users = (List<User>) excel;
        try {
            for (User user:
                    users) {
                userService.save(user);
            }
            session.removeAttribute("excel");
            return Response.success("保存成功");
        } catch (Exception e) {
            return Response.err("保存失败");
        }

    }
}
