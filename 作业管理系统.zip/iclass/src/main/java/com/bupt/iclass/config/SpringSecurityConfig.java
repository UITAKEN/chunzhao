package com.bupt.iclass.config;

import com.bupt.iclass.model.Response;
import com.bupt.iclass.util.Md5Encoder;
import com.bupt.iclass.util.Util;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
@Order(-1)
public class SpringSecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    UserDetailsService userDetailsService;

    /**
     * 权限验证
     */
    @Autowired
    AuthenticationAccessDeniedHandler deniedHandler;

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService).passwordEncoder(new Md5Encoder());
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests()
                .antMatchers("/").permitAll()
                .antMatchers("/hello").permitAll()
                .anyRequest().authenticated()
                .and()
                .formLogin().loginPage("/login_p").loginProcessingUrl("/login")
                .usernameParameter("id").passwordParameter("password")
                .defaultSuccessUrl("/pass")
                .failureHandler((req, resp, e) -> {
                    resp.setContentType("application/json;charset=utf-8");
                    Response respBean;
                    if (e instanceof BadCredentialsException ||
                            e instanceof UsernameNotFoundException) {
                        respBean = Response.err("账户名或者密码输入错误!");
                    } else {
                        respBean = Response.err("登录失败!");
                    }
                    resp.setStatus(200);
                    out(resp, respBean);
                })
                .successHandler((req, resp, auth) -> {
                    // auth.setAuthenticated(true);
                    resp.setContentType("application/json;charset=utf-8");
                    Response response = Response.success(Util.getCurrentUser());
                    out(resp, response);
                })
                .permitAll()
                .and()
                // 注意：logout要使用post请求
                .logout().logoutUrl("/logout").permitAll().logoutSuccessUrl("/exit"); // logoutSuccessUrl:注销成功时跳转到的url

        http.requestMatchers()
                .antMatchers(HttpMethod.OPTIONS, "/**")
                .antMatchers(HttpMethod.POST, "/**")
                .and()
                .cors()
                .and()
                .csrf().disable()
                .exceptionHandling().accessDeniedHandler(deniedHandler);
    }

    /**
     * 向前端返回结果信息
     * @param resp
     * @param response
     * @throws IOException
     */
    private void out(HttpServletResponse resp, Response response) throws IOException {
        ObjectMapper om = new ObjectMapper();
        PrintWriter out = resp.getWriter();
        out.write(om.writeValueAsString(response));
        out.flush();
        out.close();
    }

    @Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring().antMatchers("/js/**","/css/**","/images/**");
    }
}
