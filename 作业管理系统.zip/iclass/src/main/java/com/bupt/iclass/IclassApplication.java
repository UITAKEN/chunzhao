package com.bupt.iclass;

import com.bupt.iclass.config.SwaggerConfig;
import com.bupt.iclass.model.Response;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@RestController
@SpringBootApplication
@EnableSwagger2
@Import({SwaggerConfig.class})
@EnableGlobalMethodSecurity(prePostEnabled = true)
@Api(description = "应用后台根路径，包含登录与注销")
@CrossOrigin
public class IclassApplication extends SpringBootServletInitializer {

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(IclassApplication.class);
    }

    public static void main(String[] args) {
        SpringApplication.run(IclassApplication.class, args);
    }

    @GetMapping("/")
    public Response hello() {
        return Response.success("Hello iclass.");
    }
    // @PreAuthorize("hasRole('ROLE_ADMIN')")
    @GetMapping("/hello")
    public Response hello1() {
        return Response.success("This is spring security.");
    }
    @GetMapping("/error")
    public Response error() {
        return Response.err("There is something wrong.");
    }


    @ApiOperation(value = "判断用户是否登录", response = Response.class)
    @GetMapping("/isLogin")
    /**
     * 判断用户是否登录
     */
    public Response isLogin(@RequestParam Integer id, @RequestParam String password) {
        return Response.success();
    }


    @ApiOperation(value = "登陆", response = Response.class)
    @RequestMapping("/login_p")
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public Response login() {
        return Response.err("尚未登录，请登录!");
    }

    @ApiOperation(value = "登陆成功跳转的页面", response = Response.class)
    @RequestMapping("/pass")
    public Response pass() {
        return Response.success("登陆成功，欢迎使用");
    }

    @ApiOperation(value = "注销,同时清除session会话资源", response = Response.class)
    @RequestMapping("/exit")
    public Response logout(HttpServletRequest request) {
        HttpSession session = request.getSession();
        session.removeAttribute("user");
        return Response.success("退出登录成功，感谢使用");
    }

}
