package com.bupt.iclass.repository;

public interface ScoreRepository {
}
