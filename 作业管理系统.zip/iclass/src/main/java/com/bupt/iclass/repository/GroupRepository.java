package com.bupt.iclass.repository;

import com.bupt.iclass.model.StuGroup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface GroupRepository extends JpaRepository<StuGroup, String> {
    Optional<StuGroup> findById(String id);

    /**
     * 修改小组名称
     *
     * @return
     */
//    @Modifying
//    @Query("update StuGroup g set g.name = ?1 where g.id = ?2")
//    int modifyName(String name, String id);

    @Query(value = "select max(serial) from iclass.stu_group as g where g.pre_serial = ?1", nativeQuery = true)
    Integer findMaxSerial(String preSerial);

    List<StuGroup> findByPreSerial(String preSerial);

    @Query(value = "select * from iclass.student join stu_group_map natural join stu_group where sid = stu_id and sid = ?1", nativeQuery = true)
    List<StuGroup> findAllGroupsByStuId(Integer stuId);
}

