package com.bupt.iclass.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;


/**
 * 助教实体类
 * 暂不考虑
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Assistant {
    @Id
    private Integer id; // 助教ID
    private String name;
    private String tel;
}