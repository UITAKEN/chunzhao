package com.bupt.iclass.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Set;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Teacher {
    @Id
    private Integer tid;
    private String department;// 学院
    private String title;// 职称

    @OneToMany(fetch=FetchType.EAGER,targetEntity=Course.class,cascade=CascadeType.ALL,orphanRemoval=true,mappedBy="teacher")
    private Set<Course> courses;

    // @OneToOne(fetch = FetchType.LAZY, cascade=CascadeType.ALL)
    // // @OneToOne(cascade = CascadeType.ALL)
    // @JoinColumn(name = "t_id") // t_id为外键的名称
    // private User user;
}
