package com.bupt.iclass.model;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;

/**
 * 小组配置信息
 * 设置小组人员数（比如1-5，即min=1, max=5），设置小组编号前缀
 * （比如2012-01-A，前四位代表年份，中间2位代表班级最后一位代表序号，序号由系统自动产生）
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class GroupConfig implements Serializable {
    @Id
    @Getter @Setter
    private String preSerial; // 小组序号前缀
    @Getter @Setter
    private int minMembers;// 最小组员数
    @Getter @Setter
    private int maxMembers;// 最大组员数





}
