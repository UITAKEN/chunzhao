package com.bupt.iclass.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Entity
// @Data
// @AllArgsConstructor
@Table(name = "homework")
public class Homework {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Getter @Setter
    private Integer id;
    @Getter @Setter
    private String title; // 作业名称
    @Getter @Setter
    private String tasks; // 作业要求/任务

    // 作业成绩比例
    @Getter @Setter
    private Integer percent; // 作业成绩比例

    @Getter @Setter
    private Date createDate; // 创建时间
    @Getter @Setter
    private Date deadline; // 截止日期

    @Setter
    @ManyToOne(fetch = FetchType.EAGER,targetEntity = Course.class)
    @JoinColumn(name = "cid", referencedColumnName = "cid")
    private Course course; // 作业所属的课程

    public Homework() {
    }

    public Homework(Integer id, String title, String tasks, Date createDate, Date deadline, Course course) {
        this.id = id;
        this.title = title;
        this.tasks = tasks;
        this.createDate = createDate;
        this.deadline = deadline;
        this.course = course;
    }
}
