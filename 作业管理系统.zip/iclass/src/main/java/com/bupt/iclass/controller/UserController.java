package com.bupt.iclass.controller;

import com.bupt.iclass.model.Response;
import com.bupt.iclass.model.User;
import com.bupt.iclass.service.AuthorityService;
import com.bupt.iclass.service.RoleService;
import com.bupt.iclass.service.UserService;
import com.bupt.iclass.util.Md5Encoder;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Optional;

// import com.bupt.iclass.repository.RoleAuthRepository;


/**
 * 处理用户基本功能，如登录登出，密码修改等
 */
@RestController
@CrossOrigin
// @PreAuthorize("hasRole('ROLE_users')")
@RequestMapping("/user")
@Slf4j
@Api(description = "用户功能接口")
public class UserController {

    // @Autowired
    // RoleAuthRepository roleAuthRepository;

    @Autowired
    UserService service;
    @Autowired
    RoleService roleService;

    @Autowired
    AuthorityService authorityService;

    // private final String CURRENT_USER = "user";

    /**
     * 注意处理用户登录失败时候的情形
     */
    // @ApiOperation(value = "登陆", response = Response.class)
    // @RequestMapping("/login")
    // public Response login(User user) {
    //     log.info(user.getId().toString());
    //     log.info(user.getPassword());
    //     // log.info(user.toString());
    //     // Optional 类是一个可以为null的容器对象。如果值存在则isPresent()方法会返回true，调用get()方法会返回该对象。
    //     return Response.success("fuck");
    // }

    /**
     * 该段代码没有用
     * @param id
     * @param password
     * @param request
     * @return
     */
    @ApiOperation(value = "登陆", response = Response.class)
    @RequestMapping("/login")
    public Response login(@RequestParam Integer id, @RequestParam String password, HttpServletRequest request) {
        // Optional 类是一个可以为null的容器对象。如果值存在则isPresent()方法会返回true，调用get()方法会返回该对象。
        Optional<User> optionalUser = service.findById(id);
        if (!optionalUser.isPresent()) return new Response(false,"用户ID不存在");
        User user = optionalUser.get();
        log.info(user.toString());
        log.info(Md5Encoder.encode(password));
        if (!Md5Encoder.encode(password).equals(user.getPassword())) return new Response(false,"密码错误");
        HttpSession session = request.getSession();
        session.setAttribute("user", user);
        return Response.success(user);
    }


    /**
     * 用户首次登陆时修改此状态标记
     * 1——首次登陆；0——非首次登陆
     * @param id
     * @return
     */
    @ApiOperation(value = "修改用户首次登陆标记", response = Response.class)
    @PostMapping("/modify/first")
    public Response modifyLogin(@RequestParam Integer id) {
        // service.
        int result = service.modifyFirstLogin(0,id);
        if (result != 1)
            return new Response(result,false,"error");
        return new Response(result,true);
    }

    /**
     * 修改密码——正常功能完成
     * @return
     */
    @ApiOperation(value = "修改密码", response = Response.class)
    @PostMapping("/password")
    public Response modifyPassword(@RequestParam String password, @RequestParam Integer id) {
        User user = service.findById(id).get();
        user.setPassword(password);
        user.setIsFirstLogin(0);
        User save = service.save(user);
        if (save != null) return Response.success(save);
        return Response.err("修改密码失败");
    }

    /**
     * 修改用户个人信息，包含用户姓名和密码
     * id等个人信息暂不考虑
     * @param name
     * @param password
     * @param id
     * @return
     */
    @ApiOperation(value = "修改个人信息", response = Response.class)
    @PostMapping("/modify/profile")
    @PreAuthorize("hasAnyRole('ROLE_profile')")
    public Response modifyUserProfile(@RequestParam String name, @RequestParam String password, @RequestParam Integer id) {
        Optional<User> optional = service.findById(id);
        // return optional.map(user -> new Res).orElseGet(() -> new Response(false,"修改失败"));
        if (!optional.isPresent())  return new Response(false,"修改失败");
        User user = optional.get();
        user.setName(name);
        user.setPassword(Md5Encoder.encode(password));
        User save = service.save(user);
        if (save == null) return new Response(false,"修改失败");
        return new Response(save,true);
    }

    /**
     * 添加用户
     * @param user
     * @return
     */
    @ApiOperation(value = "添加用户", response = Response.class)
    @PostMapping("/add")
    public Response addUser(User user) {
        User save = service.save(user);
        if (save == null) return new Response(user,false,"添加用户失败");
        return new Response(save,true,"success");
    }

    /**
     * 根据用户ID获取用户信息
     * @param id
     * @return
     */
    @ApiOperation(value = "根据用户ID获取用户信息", response = Response.class)
    @GetMapping("/{id}")
    public Response getUser(@PathVariable("id") Integer id) {
        Optional<User> optional = service.findById(id);
        return optional.map(user -> new Response(user,true)).orElseGet(() -> new Response(false,"用户不存在"));
    }

    @GetMapping("/id")
    public Response getUser1(@RequestParam Integer id) {
        Optional<User> optional = service.findById(id);
        return optional.map(user -> new Response(user,true)).orElseGet(() -> new Response(false,"用户不存在"));
    }
    /**
     * 获取所有用户信息
     * @return 用户集合列表
     */
    @ApiOperation(value = "获取所有用户信息", response = Response.class)
    @GetMapping("/allUsers")
    public Response getAllUsers() {
        List<User> allUser = service.findAllUser();
        if (allUser == null) return new Response(false,"获取失败，请稍后再试");
        return new Response(allUser,true);
    }


    /**
     * 分页查询
     * 获取部分用户信息
     * @param page 页号
     * @param size 每页的大小
     * @return
     */
    @ApiOperation(value = "分页查询，获取部分用户信息", response = Response.class)
    @GetMapping("/users")
    public Response getUsersByPage(@RequestParam(value = "page", defaultValue = "0") Integer page, @RequestParam(value = "size", defaultValue = "10") Integer size, @RequestParam(value = "asc", defaultValue = "0") Integer asc) {
        Sort sort = null;
        if (asc == 0)
            sort = new Sort(Sort.Direction.ASC, "id");
        else sort = new Sort(Sort.Direction.DESC, "id");
        Pageable pageable = PageRequest.of(page, size, sort);
        Page<User> users = service.findAll(pageable);
        if (users == null) return new Response(false,"error");
        return new Response(users,true);
    }

    /**
     * 按照角色进行分页查询
     * @param role
     * @param page
     * @param size
     * @param asc
     * @return
     */
    // @GetMapping("/users/{role}")
    // public Response getUsersByPage(@PathVariable("role") Integer role,  @RequestParam(value = "page", defaultValue = "0") Integer page, @RequestParam(value = "size", defaultValue = "10") Integer size, @RequestParam(value = "asc", defaultValue = "0") Integer asc) {
    //     Sort sort;
    //     if (asc == 0)
    //         sort = new Sort(Sort.Direction.ASC, "id");
    //     else sort = new Sort(Sort.Direction.DESC, "id");
    //     Pageable pageable = new PageRequest(page, size, sort);
    //     Page<User> users = service.findByRole(role,pageable);
    //     if (users == null) return new Response(false,"error");
    //     return new Response(users,true);
    // }

    // @PostMapping("/test")
    // public Response test(@RequestParam String str) {
    //     System.out.println(str);
    //     return new Response(str,true);
    // }


    /**
     * 根据用户ID获取该用户的角色信息及角色所拥有的权限
     * @param id 用户id
     * @return
     */
    @ApiOperation(value = "根据用户ID获取该用户的角色信息及角色所拥有的权限", response = Response.class)
    @GetMapping("/auth/{id}")
    public Response getUserAuths(@PathVariable("id") Integer id) {
        // Optional<User> user = service.findById(id);
        // int role = user.get().getRole();
        // return null;

        // List<Authority> authorities = roleAuthRepository.findAuthByRoleId(id);
        // return new Response(authorities,true, "success");
        return null;
    }
    @ApiOperation(value = "通过用户Id删除用户", response = Response.class)
    @DeleteMapping("/delete")
    public Response deleteUser(@RequestParam("id") Integer id) {
        // 通过id查找待删除的用户
        Optional<User> user = service.findById(id);
        if (!user.isPresent()) return new Response(false,"用户不存在");
        try {
            service.deleteUser(user.get());
            return new Response(true,"删除成功");
        } catch (Exception e) {
            return new Response(false,e.getMessage());
        }
    }

    /**
     * 获取当前已经登录的用户信息
     * @return
     */
    @GetMapping("/get_info")
    public Response getCurrentUser() {
        SecurityContext context = SecurityContextHolder.getContext();
        Authentication authentication = context.getAuthentication();
        Object principal = authentication.getPrincipal();


        // UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication() .getPrincipal();

        if (principal != null)
            return Response.success(principal);
        else return Response.err();
    }

    /**
     * 判断用户是否已经登陆
     * @return
     */
    @GetMapping("/isLogin")
    public Response isLogin() {
        return Response.success();
    }
}
