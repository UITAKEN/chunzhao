package com.bupt.iclass.repository;

import com.bupt.iclass.model.Admin;
import com.bupt.iclass.model.Message;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface MessageRepository extends JpaRepository<Message, Integer> {

    @Query(value = "select * from message where stu_id = ?1", nativeQuery = true)
    List<Message> findByStuId(Integer stuId);
}
