package com.bupt.iclass.service;

import java.util.List;
import java.util.Optional;

import com.bupt.iclass.model.GroupConfig;
import com.bupt.iclass.repository.GroupConfigRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class GroupConfigService {
    @Autowired
    private GroupConfigRepository repository;

    public List<GroupConfig> findAllConfigs() {
        return repository.findAll();
    }

    /**
     * 添加一条小组配置信息
     * @param config
     * @return
     */
    public GroupConfig save(GroupConfig config) {
        return repository.save(config);
    }

    public Optional<GroupConfig> findById(String id) {
        return repository.findById(id);
    }

    /**
     * 更新小组配置信息，可以设置多个小组配置信息以供选择
     * @param config
     * @return
     */
    public GroupConfig update(GroupConfig config) {
        return null;
    }

    public void delConfig(String confId) {
        repository.deleteById(confId);
    }
}