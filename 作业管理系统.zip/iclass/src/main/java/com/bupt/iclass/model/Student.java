package com.bupt.iclass.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;


@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Student {
    @Id
    @Getter @Setter
    private Integer sid;// 学生ID
    @Getter @Setter
    private Integer classId; // 班级ID
    @Getter @Setter
    private String department;// 学院
    @Getter @Setter
    private String major;// 专业

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "uid") // 外键，引用user中的id
    @Setter @Getter
    private User user; // 学生用户的通用信息，如学号，用户名等


    /**
     * 分组——学生映射关系: 多对多
     * 学生所在小组
     */
    @ManyToMany(fetch = FetchType.EAGER,targetEntity = StuGroup.class)
    @JoinTable(name = "stu_group_map", joinColumns = @JoinColumn(name = "stuId"), inverseJoinColumns = @JoinColumn(name = "groupId"))
    @Setter // @Getter
    private List<StuGroup> groupList;


    @Getter @Setter
    @ManyToMany
    @JoinTable(name = "stu_course", joinColumns = @JoinColumn(name = "sid"), inverseJoinColumns = @JoinColumn(name = "cid"))
    private List<Course> courses;// 学生所选课程 ManyToMany


    public Student(Integer id, Integer classId, String department, String major, User user) {
        this.sid = id;
        this.classId = classId;
        this.department = department;
        this.major = major;
        this.user = user;
    }
}
