package com.bupt.iclass.controller;

import com.alibaba.fastjson.JSONObject;
import com.bupt.iclass.model.Course;
import com.bupt.iclass.model.Response;
import com.bupt.iclass.model.StudentX;
import com.bupt.iclass.model.User;
import com.bupt.iclass.model.Student;
import com.bupt.iclass.model.Teacher;
import com.bupt.iclass.service.CourseService;
import com.bupt.iclass.service.StudentService;
import com.bupt.iclass.service.TeacherService;
import com.bupt.iclass.service.UserService;
import com.bupt.iclass.util.Util;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.*;

@RestController
@RequestMapping("/teacher")
@Slf4j
@CrossOrigin
public class TeacherController {
    @Autowired
    TeacherService service;

    @Autowired
    UserService userService;

    @Autowired
    StudentService studentService;

    @Autowired
    CourseService courseService;
    /**
     * 获取所有教师信息
     * @return
     */
    @GetMapping("/teachers")
    public Response getAllTeachers() {
        List<Teacher> teachers = service.findAll();
        return new Response(teachers,true);
    }


    @GetMapping("/{id}")
    public Response getTeacher(@PathVariable("id") Integer id) {
        Optional<Teacher> optional = service.findById(id);
        return optional.map(teacher -> new Response(teacher,true)).orElseGet(() -> new Response(false,"该教师ID不存在"));
    }

    /**
     * 添加课程
     * @param id
     * @param name
     * @return
     */
    @PostMapping("/course")
    public Response addCourse(@RequestParam Integer id, @RequestParam String name) {
        Response response = new Response();

        return response;
    }

    /**
     * 根据教师id获取该教师的所有课程
     * @param
     * @return
     */

    // TODO 调整返回数据格式
    @GetMapping("/courses")
    public Response getCourseByTeacherId(@RequestParam("id") Integer id) {
//        User user = Util.getCurrentUser(request);
        User user = userService.findById(id).get();
        if (user == null)
            return Response.err("服务出错，请重新登录");
        Optional<Teacher> optional = service.findById(user.getId());
        Teacher teacher = optional.get();
        Set<Course> courses = teacher.getCourses();
        List<JSONObject> data = new ArrayList<>();
        for (Course course : courses) {
            JSONObject jsonObject = new JSONObject();
            jsonObject.fluentPut("cid", course.getCid());
            StudentController.jsonData(data, course, user, jsonObject);
        }
        return Response.success(data);
    }

    /**
     * 教师通过给出与课程关联的学生名单Excel导入多个班级的学生名单
     * 批量导入学生信息
     * @param file
     * @return
     */
    @PostMapping("/import")
    public Response importStudent(@RequestParam("excel") MultipartFile file, HttpServletRequest request) {
        // List<Student> studentList = new ArrayList<>();
        try {
            List<StudentX> students = Util.importExcel(file,1,1, StudentX.class);
            HttpSession session = request.getSession();
            session.setAttribute("stus", students);
            return Response.success(students);
        } catch (Exception e) {
            return Response.err("导入失败");
        }
    }

    /**
     * 获取session中保存的学生数据列表
     * @param request
     * @return
     */
    @GetMapping("/excel")
    public Response getSessionStus(HttpServletRequest request) {
        HttpSession session = request.getSession();
        Object stus = session.getAttribute("stus");
        if (stus == null) return Response.err("请上传Excel文件");
        return Response.success(stus);
    }

    /**
     *
     * @param
     * @return
     */
    @PostMapping("/save")
    public Response saveExcelData(HttpServletRequest request, @RequestParam("stuList") String ids, @RequestParam("courseId") String courseId) {
        String[] strings = ids.split(",");
        List<Integer> idList = new ArrayList<>();
        for (int i = 0; i < strings.length; i++) {
            idList.add(Integer.valueOf(strings[i]));
            log.info(strings[i]);
        }

        Optional<Course> course = courseService.findById(courseId);
        for (Integer id
                : idList) {
            Optional<Student> optionalStudent = studentService.findById(id);
            if (optionalStudent.isPresent()) {
                Student student = optionalStudent.get();
                List<Course> courses = student.getCourses();
                courses.add(course.get());
                student.setCourses(courses);
                studentService.save(student);
            }
        }
        HttpSession session = request.getSession();
        session.removeAttribute("stus"); // 删除session中保存的学生名单
        return Response.success("保存成功");
    }

    @PostMapping("/saveStus")
    public Response saveStus(@RequestParam("courseId") String courseId, @RequestParam("stuList") String stuList) {
        List<String> ids = new ArrayList<>();
        String[] split = stuList.split(",");
        Course course = courseService.findById(courseId).get();
        for (int i = 0; i < split.length; i++) {
            Student student = studentService.findById(Integer.valueOf(split[i])).get();
            log.info(student.toString());
            List<Course> courses = student.getCourses();
            courses.add(course);
            student.setCourses(courses);
            studentService.save(student);
        }
        return Response.success();
    }

 }
