package com.bupt.iclass.controller;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.bupt.iclass.model.Response;
import com.bupt.iclass.model.auth.Role;
import com.bupt.iclass.model.Admin;
import com.bupt.iclass.model.User;
import com.bupt.iclass.model.Student;
import com.bupt.iclass.service.AdminService;
import com.bupt.iclass.service.RoleService;
import com.bupt.iclass.service.StudentService;
import com.bupt.iclass.service.UserService;
import com.bupt.iclass.util.Md5Encoder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin
@RequestMapping("/admin")
@Api(description = "管理员操作接口")
public class AdminController {

    @Autowired
    UserService userService;

    @Autowired
    AdminService service;

    @Autowired
    RoleService roleService;

    @Autowired
    StudentService studentService;

    /**
     * 确定保存从Excel导入的数据
     * @return
     */
    @ApiOperation("保存由Excel导入的用户信息")
    @PostMapping("/save")
    public Response saveUsers(HttpServletRequest request) {
        HttpSession session = request.getSession();
        List<User> users = (List<User>) session.getAttribute("excel");
        try {
            for (User user :
                    users) {
                user.setPassword(Md5Encoder.encode(user.getPassword()));
                userService.save(user);
            }
        } catch (Exception e) {
            return new Response(false,"保存失败");
        }
        session.removeAttribute("excel"); // 用户导入成功，删除session
        return new Response(users,true);
    }

    /**
     * 逐个添加用户
     *
     * @param user
     * @return
     */

    @ApiOperation("添加一个学生")
    @PostMapping("/addStu")
    public Response addUser(User user,
                            @RequestParam("classId") Integer classId,
                            @RequestParam("department") String dep,
                            @RequestParam("major") String major) {
        //
        // User save = userService.save(user);
        // if (save != null)
        //     return new Response(save,true);
        // else return new Response(false,"添加失败");
        user.setPassword(Md5Encoder.encode(user.getPassword()));
        Optional<Role> role = roleService.findByRoleId(user.getRole());
        user.setUserRole(role.get());
        user.setIsFirstLogin(1);
        Student student = new Student(user.getId(), classId, dep, major, user);

        Student save = studentService.save(student);


        if (save == null) return Response.err("添加用户失败");
        return Response.success(save);
    }

    @ApiOperation("删除用户")
    @DeleteMapping("/delete")
    public Response delUser(User user) {
        try {
            userService.deleteUser(user);
            return new Response(true,"删除成功");
        } catch (Exception e) {
            return new Response(false,e.getMessage());
        }

    }

    @ApiOperation("添加一个管理员用户")
    public Response add(Admin admin) {
        Admin save = service.save(admin);
        if (save == null) return new Response(false,"保存失败");
        return new Response(save, true);
    }

    @PostMapping("/addUser")
    public Response addUser(User user, @RequestParam("role") Integer roleId) {
        Role role = roleService.findByRoleId(roleId).get();
        user.setUserRole(role);
        User save = userService.save(user);
        return Response.success(save);
    }
}
