package com.bupt.iclass.service;

import com.bupt.iclass.model.User;
import com.bupt.iclass.model.auth.Role;
import com.bupt.iclass.repository.RoleRepository;
import com.bupt.iclass.repository.UserRepository;
import com.bupt.iclass.util.Md5Encoder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.authentication.AccountStatusUserDetailsChecker;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Slf4j
@Component
@Service(value="userDetailsService")
public class UserService implements UserDetailsService {

    @Autowired
    UserRepository repository;

    @Autowired
    RoleRepository roleRepository;
    @Override
    public UserDetails loadUserByUsername(String input) {
        log.info("id:" + input);
        Optional<User> user = repository.findById(Integer.valueOf(input));

        // if (input.contains("@"))
        //     user = userRepository.findByEmail(input);
        // else
        //     user = repository.findByUsername(input);

        if (!user.isPresent())
            throw new UsernameNotFoundException("用户不存在");

        new AccountStatusUserDetailsChecker().check(user.get());

        return user.get();
    }

    public User findByIdAndPassword(Integer id, String password) {
        return repository.findByIdAndPassword(id, password);
    }

    public Optional<User> findById(Integer id) {
        return repository.findById(id);
    }

    public User save(User user) {
        String password = user.getPassword();
        user.setPassword(Md5Encoder.encode(password));
        int roleId = user.getRole();
        Optional<Role> optionalRole = roleRepository.findByRoleId(roleId);
        Role role = optionalRole.get();
        user.setUserRole(role);
        return repository.save(user);
    }
    public List<User> findAllUser() {
        return repository.findAll();
    }
    public int modifyPassword(String password, Integer id) {
        return repository.modifyPassword(password, id);
    }

    public int modifyFirstLogin(int first, Integer id) {
        return repository.modifyFirstLogin(first, id);
    }

    public Page<User> findAll(Pageable pageable) {
        return repository.findAll(pageable);
    }

    /**
     * 根据用户角色进行分页查询
     * @param role
     * @param pageable
     * @return
     */

    public Page<User> findByRole(Integer role, Pageable pageable) {
        // return repository.findByRole(role, pageable);
        return null;
    }

    /**
     * 删除用户
     * @param user
     */
    public void deleteUser(User user) {
        repository.delete(user);
    }


}
