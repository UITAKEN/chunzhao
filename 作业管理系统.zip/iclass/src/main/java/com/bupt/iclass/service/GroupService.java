package com.bupt.iclass.service;

import com.bupt.iclass.model.StuGroup;
import com.bupt.iclass.repository.GroupRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class GroupService {
    @Autowired
    private GroupRepository repository;
    public List<StuGroup> findAllGroups() {
        return repository.findAll();
    }
    public StuGroup save(StuGroup group) {
        return repository.save(group);
    }

//    public int modifyName(String id, String name) {
//        return repository.modifyName(name,id);
//    }

    public Optional<StuGroup> findById(String id) {
        return repository.findById(id);
    }
}
