package com.bupt.iclass.model.auth;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Role {
    @Id
    private Integer roleId;
    private String roleName;
    private String roleIntro; // 角色描述

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "role_authority",joinColumns = @JoinColumn(name = "role_id"),
            inverseJoinColumns = @JoinColumn(name = "auth_id"))
    private List<Authority> authorities;
}
