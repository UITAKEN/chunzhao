package com.bupt.iclass.model;

import com.alibaba.fastjson.JSON;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 用于处理返回信息
 * 对需要返回的Model信息进行加工，添加任务执行结果以及错误代码等
 */
@Data
@AllArgsConstructor
@ApiModel("请求返回消息")
public class Response {
    @ApiModelProperty("消息正文")
    private Object body; // 消息正文
    @ApiModelProperty("请求是否成功")
    private boolean success; // 处理状态
    @ApiModelProperty("错误代码")
    private String error; // 错误代码

    public Response() {}

    public Response(String error){
        this.error = error;
    }

    public Response(boolean success, String error) {
        this.success = success;
        this.error = error;
    }

    public Response(Object body) {
        this.body = body;
    }

    public Response(Object body, boolean success) {
        this.body = body;
        this.success = success;
    }

    public static Response success(Object body) {
        return new Response(body,true);
    }

    public static Response success() {
        return new Response(null,true);
    }

    public static Response err(String error) {
        return new Response(false,error);
    }

    public static Response err() {
        return new Response(null,false);
    }
    // public Response(boolean isSuccess, String error, String errorCode) {
    //     this.isSuccess = isSuccess;
    //     this.error = error;
    //     // this.errorCode = errorCode;
    // }
}
