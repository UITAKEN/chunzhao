package com.bupt.iclass.repository;

import com.bupt.iclass.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StudentRepository extends JpaRepository<Student, Integer> {
    public Optional<Student> findById(Integer id);

    // Teacher findById(@Param("id") Integer id);

    /**
     * 根据课程获取该课程的学生名单
     * @param cid 课程id
     * @return
     */
    @Query(value = "select * from stu_course natural join course where cid = :cid ", nativeQuery = true)
    List<Student> findStudentsByCourseId(@Param("cid") String cid);

    List<Student> findByDepartment(String department);

    @Query(value = "select sid from stu_course where cid = :cid", nativeQuery = true)
    List<Integer> findStudentIdsByCourseId(@Param("cid") String courseId);
}
