package com.bupt.iclass.service;

import java.util.List;
import java.util.Optional;

import com.bupt.iclass.model.auth.Authority;
import com.bupt.iclass.repository.AuthorityRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthorityService {
    @Autowired
    private AuthorityRepository repository;

    public List<Authority> findAllAuthorities() {
        return repository.findAll();
    }

    public Optional<Authority> findById(Integer id) {
        return repository.findById(id);
    }
    public Authority save(Authority authority) {
        return repository.save(authority);
    }
}
