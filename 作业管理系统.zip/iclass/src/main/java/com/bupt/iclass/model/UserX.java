package com.bupt.iclass.model;

import cn.afterturn.easypoi.excel.annotation.Excel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;


/**
 * user model
 */
@Slf4j
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserX {
    @Excel(name = "ID")
    private Integer id;

    @Excel(name = "用户名", orderNum = "3")
    private String userName;// user name

    @Excel(name = "姓名", orderNum = "1")
    private String name;// 昵称/姓名

    @Excel(name = "密码", orderNum = "2")
    private String password;

    @Excel(name = "角色", orderNum = "4")
    private int role; // 用户角色，一对一，一个用户只有一个角色

    @Excel(name = "首次登陆", orderNum = "5")
    private int isFirstLogin;

}

