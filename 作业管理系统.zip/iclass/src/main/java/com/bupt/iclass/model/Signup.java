package com.bupt.iclass.model;

import java.util.Date;

/**
 * 点名记录
 */
public class Signup {
    private Integer id;

    private Student student; // 学生
    private String courseId;
    private Date time; // 点名时间
}
