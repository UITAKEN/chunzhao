package com.bupt.iclass.controller;

import java.util.List;
import java.util.Optional;

import com.bupt.iclass.model.GroupConfig;
import com.bupt.iclass.model.Response;
import com.bupt.iclass.service.GroupConfigService;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/groupConf")
@Slf4j
@CrossOrigin
public class GroupConfigController {
    @Autowired
    GroupConfigService service;

    @GetMapping("/configs")
    public Response getAllConfigs() {
        List<GroupConfig> configs = service.findAllConfigs();
        if (configs == null || configs.isEmpty()) return new Response(false, "小组配置信息获取失败，请重试");
        return new Response(configs,true);
    }

    @GetMapping("/{id}")
    public Response getConfig(@PathVariable("id") String id) {
        Optional<GroupConfig> optionalGroupConfig = service.findById(id);
        return optionalGroupConfig.map(config -> new Response(config,true)).orElseGet(()->new Response(false,"小组配置信息获取失败"));
    }

    @PostMapping("/update")
    public Response updateConfig(GroupConfig config) {
        GroupConfig update = service.update(config);
        if (update == null) return new Response(false,"更新小组配置失败，请重试");
        return new Response(update,true);
    }

    @PostMapping("/add")
    public Response addConfig(GroupConfig config) {
        // log.info(config.toString());
        // config.setPreSerial();
        GroupConfig save = service.save(config);
        if (save == null) {
            return Response.err("添加失败，请稍后再试");
        }
        return Response.success(save);
    }

    @DeleteMapping("/{confId}")
    public Response delConf(@PathVariable("confId") String confId) {
        try {
            service.delConfig(confId);
            return Response.success("删除成功");
        } catch (Exception e) {
            return Response.err("删除失败");
        }
    }

}
