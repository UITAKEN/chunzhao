package com.bupt.iclass.service;

import com.bupt.iclass.model.Homework;
import com.bupt.iclass.repository.HomeworkRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class HomeworkService {
    @Autowired
    private HomeworkRepository repository;

    public List<Homework> findAllWorks() {
        return repository.findAll();
    }

    public Optional<Homework> findById(Integer id) {
        return repository.findById(id);
    }
    public Homework addHomework(Homework homeWork) {
        return repository.save(homeWork);
    }
    public int deleteById(Integer id) {
        try {
            repository.deleteById(id);
            return 1;
        } catch (Exception e) {
            log.info(e.getMessage());
            return 0;
            // return e.getMessage();
        }

    }

    /**
     * 提交作业
     * @param hId
     * @return
     */
    public Homework submitWirk(Integer hId) {
        return null;
    }

    /**
     * 检查作业是否已经提交
     * @return
     */
    private boolean checkSubmmit(Integer sId) {
        return true;
    }

}
