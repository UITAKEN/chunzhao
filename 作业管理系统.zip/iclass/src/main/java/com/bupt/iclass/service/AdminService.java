package com.bupt.iclass.service;

import java.util.List;
import java.util.Optional;

import com.bupt.iclass.model.Admin;
import com.bupt.iclass.repository.AdminRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class AdminService {
    @Autowired
    private AdminRepository repository;

    public List<Admin> findAllAuthorities() {
        return repository.findAll();
    }

    public Optional<Admin> findById(Integer id) {
        return repository.findById(id);
    }
    public Admin save(Admin admin) {
        return repository.save(admin);
    }

    public int deleteAdmin(Integer id) {
        try {
            repository.deleteById(id);
            return 1; // 成功删除时返回1
        } catch (Exception e) {
            log.info(e.getMessage());
            return 0; // 删除失败返回0
        }
    }
}
