package com.bupt.iclass.model;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
public class Course {
    @Id
    @Getter
    @Setter
    // @GeneratedValue(strategy = GenerationType.AUTO)
    @GenericGenerator(name = "system-uuid", strategy = "uuid")
    @GeneratedValue(generator = "system-uuid")
    private String cid;//课程序号id
    @Getter
    @Setter
    private String courseName;// 课程名称
    @Getter
    @Setter
    private int score;// 学分
    @Getter
    @Setter
    private Date createDate;//创建日期：获取系统时间
    @Getter
    @Setter
    private Integer allCallNumber;//本门课程的点名次数
    @Getter
    @Setter
    private Integer onCallScore;//一次点名的得分
    @Getter
    @Setter
    private String intro;// 课程简介

    /**
     * 教师——课程映射关系
     */
    @ManyToOne(fetch = FetchType.EAGER,targetEntity = Teacher.class)
    @JoinColumn(name = "tid")
    @Setter
    private Teacher teacher;//教师id->教师名称

    /**
     * 课程——作业映射关系，一对多
     */
    @OneToMany(fetch=FetchType.EAGER,targetEntity= Homework.class,cascade=CascadeType.ALL,orphanRemoval=true,mappedBy="course")
    // @JoinColumn(name = "id")
    @Setter @Getter
    private List<Homework> works; // 本课程所对应的所有作业

    /**
     * 课程——助教映射关系，一对一，一门课一个助教
     * @return
     */
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "a_id")
    @Setter @Getter
    private Assistant assistant;

    /**
     * 课程——学生映射关系，多对多
     * @return
     */
    @Setter
    @ManyToMany(mappedBy = "courses")
    private List<Student> students;

    public Course() {}

    public Course(String cid, String courseName, int score, Date createDate, Integer allCallNumber, Integer onCallScore, String intro, Teacher teacher, List<Homework> works) {
        this.cid = cid;
        this.courseName = courseName;
        this.score = score;
        this.createDate = createDate;
        this.allCallNumber = allCallNumber;
        this.onCallScore = onCallScore;
        this.intro = intro;
        this.teacher = teacher;
        this.works = works;
    }


}
