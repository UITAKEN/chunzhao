package com.bupt.iclass.controller;

import com.bupt.iclass.model.Response;
import com.bupt.iclass.repository.MessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
@RequestMapping("/message")
public class MessageController {
    @Autowired
    MessageRepository repository;
   @DeleteMapping("/read/{id}")
   public Response deleteMessage(@PathVariable("id") Integer id) {
       try {
           repository.deleteById(id);
           return Response.success();
       } catch (Exception e) {
           return Response.err();
       }
   }
}
