package com.bupt.iclass.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.bupt.iclass.model.GroupConfig;
import com.bupt.iclass.model.Response;
import com.bupt.iclass.model.StuGroup;
import com.bupt.iclass.model.User;
import com.bupt.iclass.model.Student;
import com.bupt.iclass.repository.GroupConfigRepository;
import com.bupt.iclass.repository.GroupRepository;
import com.bupt.iclass.repository.StudentRepository;
import com.bupt.iclass.service.GroupConfigService;
import com.bupt.iclass.service.GroupService;
import com.bupt.iclass.service.UserService;
import com.bupt.iclass.util.Util;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin
@RequestMapping("/group")
@Slf4j
public class GroupController {
    @Autowired
    GroupService service;

    @Autowired
    UserService userService;

    @Autowired
    GroupRepository groupRepository;

    @Autowired
    StudentRepository studentRepository;

    @Autowired
    GroupConfigService configService;

    @Autowired
    GroupConfigRepository groupConfigRepository;


    @GetMapping("/{id}")
    public Response getGroup(@PathVariable("id") String id) {
        Optional<StuGroup> optionalGroup = service.findById(id);
        log.info(optionalGroup.get().toString());
        return optionalGroup.map(group -> new Response(group, true)).orElseGet(() -> new Response(false, "获取失败"));
    }

    @PostMapping("/add")
    public Response addGroup(HttpServletRequest request, StuGroup group, /*@RequestParam("leaderId")*/ Integer leaderId, @RequestParam("json") String json) {
        log.info(json);
        JSONObject jsonObject = JSON.parseObject(json);
//        StuGroup stuGroup = group;
//        Optional<User> optional = userService.findById(leaderId);
//        User leader = optional.get();
//
//        stuGroup.setLeader(leader);
//        StuGroup save = service.save(group);
//        if (save == null) return new Response(false,"创建失败，请重试");
//        return new Response(save,true);
        User currentUser = Util.getCurrentUser(request);
        Optional<Student> byId = studentRepository.findById(currentUser.getId());
        Student student = byId.get();
        Integer classId = student.getClassId();
        String s = classId.toString();
        String substring = s.substring(8);
        substring = "%" + substring;
        log.info(substring);
        String config = groupConfigRepository.findConfig(substring);
        StuGroup stuGroup = createGroup(jsonObject, config);
        groupRepository.save(stuGroup);
        return Response.success(stuGroup);
    }

    @GetMapping("/groups")
    public Response getAllCourses() {
        List<StuGroup> allGroups = service.findAllGroups();
        List<JSONObject> data = new ArrayList<>();

        for (StuGroup group : allGroups) {
            JSONObject jsonObject = new JSONObject();

            jsonObject.fluentPut("id", group.getGroupId());
            jsonObject.fluentPut("memberNum", group.getMemberNum());
            jsonObject.fluentPut("leaderName", group.getLeader().getName());
            jsonObject.fluentPut("tel", group.getTel());

            data.add(jsonObject);
        }
        return Response.success(data);
    }


    /**
     * 根据小组ID获取小组配置
     * @param id
     * @return
     */
    @RequestMapping("/cnf/{id}")
    public Response getGroupConfig(@PathVariable("id") String id) {
        Optional<StuGroup> group = service.findById(id);
        boolean present = group.isPresent();
        Optional<GroupConfig> config;
        if (!present) return new Response(false,"小组不存在");
        else {
            StuGroup stuGroup = group.get();
            config = configService.findById(stuGroup.getCfgId());


        }

        return config.map(config1-> new Response(config1, true)).orElseGet(() -> new Response(false,  "小组配置不存在"));
    }

    @GetMapping("/test/{preSerial}")
    public Response test(@PathVariable("preSerial") String preSerial) {
        System.out.println(preSerial);
        // List<StuGroup> groups = groupRepository.findByPreSerial(preSerial);
        Integer maxSerial = groupRepository.findMaxSerial(preSerial);
        return Response.success(Util.createGroupId(preSerial, maxSerial));
    }

    private StuGroup createGroup(JSONObject jsonObject, String preSerial) {
        String contact = (String)jsonObject.get("contact");
//        String courseId = (String)jsonObject.get("courseId");
        List<Integer> memberIds = (List<Integer>) jsonObject.get("members");
        String s = jsonObject.get("leaderId").toString();
        Integer leaderId;
        if (!s.equals("")) {
           leaderId = Integer.valueOf(s); // leaderId可能为空
        } else {
            leaderId = Util.getCurrentUser().getId();
        }
        User leader = userService.findById(leaderId).get();

        StuGroup stuGroup = new StuGroup();
        stuGroup.setLeader(leader);
        stuGroup.setMemberNum(memberIds.size());
        List<Student> members = new ArrayList<>();
        for (int i = 0; i < memberIds.size(); i++) {
            Integer id = memberIds.get(i);
            Student student = studentRepository.findById(id).get();
            members.add(student);
        }
        stuGroup.setMembers(members);
//        stuGroup.setPreSerial(preSerial);
//        stuGroup.setSerial(serial);
        stuGroup.setTel(contact);

        Integer maxSerial = groupRepository.findMaxSerial(preSerial);
        String groupId = Util.createGroupId(preSerial, maxSerial);
        stuGroup.setGroupId(groupId);
        stuGroup.setCfgId(preSerial);
        stuGroup.setSerial(maxSerial+1);
        stuGroup.setPreSerial(preSerial);
        return stuGroup;
    }
}
