package com.bupt.iclass.repository;

import com.bupt.iclass.model.GroupConfig;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface GroupConfigRepository extends JpaRepository<GroupConfig, String> {
    Optional<GroupConfig> findById(String id);

    @Query(value = "select config.pre_serial from iclass.group_config as config where config.pre_serial like :seq", nativeQuery = true)
    String findConfig(@Param("seq") String seq);

}
