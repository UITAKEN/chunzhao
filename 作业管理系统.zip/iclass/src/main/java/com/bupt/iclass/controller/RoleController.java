package com.bupt.iclass.controller;

import com.bupt.iclass.model.Response;
import com.bupt.iclass.model.auth.Authority;
import com.bupt.iclass.model.auth.Role;
import com.bupt.iclass.repository.RoleRepository;
import com.bupt.iclass.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin
@RequestMapping("/role")
public class RoleController {
    @Autowired
    RoleService service;

    @Autowired
    RoleRepository roleRepository;

    @GetMapping("/{id}")
    public Response getRole(@PathVariable("id") Integer id) {
        Optional<Role> optionalRole = service.findByRoleId(id);
        return optionalRole.map(role -> new Response(role,true)).orElseGet(() -> new Response(false,"error"));
    }

    @GetMapping("/roles")
    public Response getAllRoles() {
        List<Role> allRoles = service.findAllRoles();
        return new Response(allRoles,true);
    }

    /**
     * 添加角色
     * @param role
     * @return
     */
    @PostMapping("/add")
    public Role addRole(Role role) {
        return roleRepository.save(role);
    }

    /**
     * 修改角色所对应的权限
     * @param authority
     * @return
     */
    @PostMapping("/modifyAuth")
    public Role modifyAuth(Authority authority) {
        // return roleRepository.save(role);

        return null;
    }
}
