package com.bupt.iclass.repository;

import com.bupt.iclass.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

// import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;
// import org.springframework.data.repository.CrudRepository;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
    User findByIdAndPassword(Integer id, String password);
    Optional<User> findById(Integer id);

    /**
     * 自定义SQL查询
     * 修改用户密码
     * 添加了对事务的支持
     * @param password
     * @param id
     * @return
     */
    // @Transactional
    @Modifying
    @Query("update User  u set  u.password = ?1 where u.id = ?2")
    int modifyPassword(String password, Integer id);

    // @Transactional
    @Modifying
    @Query("update User  u set  u.isFirstLogin = ?1 where u.id = ?2")
    int modifyFirstLogin(int first, Integer id);

    @Query("from User")
    List<User> findAllUsers();

    @Query("select new User (u.userName) from User as u")
    List<User> findUserName();

    @Query(value = "select * from user join course where user.id = course.tid and cid = :cid", nativeQuery = true)
    User findTeacherByCourseId(@Param("cid") String cid);

}
