package com.bupt.iclass.service;

import com.bupt.iclass.model.Course;
import com.bupt.iclass.repository.CourseRepository;
import com.bupt.iclass.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CourseService {
    @Autowired
    private CourseRepository repository;

    @Autowired
    private StudentRepository studentRepository;
    public List<Course> findAllCourses() {
        return repository.findAll();
    }

    public Optional<Course> findById(String id) {
        return repository.findById(id);
    }
    public Course save(Course course) {
        return repository.save(course);
    }

    public void callName() {

    }

    public Course addAssitant() {
        return null;
    }

    // public List<Student> findAllStudentsByCourse(List<Integer> ids) {
    //     return studentRepository.findAllById(ids);
    // }

}
