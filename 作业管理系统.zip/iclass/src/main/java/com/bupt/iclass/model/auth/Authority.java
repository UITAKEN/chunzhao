package com.bupt.iclass.model.auth;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import java.util.List;

/**
 * 权限信息
 */
@Entity
@Table(name = "authority")
public class Authority {
    @Id
    @Getter @Setter
    private Integer authId; // 权限ID
    @Getter @Setter
    private String authName; // 权限名称
    @Getter @Setter
    private String authIntro; // 权限描述

    /**
     * Authority——Role映射关系, 多对多
     */
    @Setter
    @ManyToMany(mappedBy = "authorities")
    private List<Role> roles;
    public Authority() {}
}
