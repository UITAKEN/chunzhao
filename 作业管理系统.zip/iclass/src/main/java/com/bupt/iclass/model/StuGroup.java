package com.bupt.iclass.model;

import java.util.List;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

// @Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "stu_group")
public class StuGroup {
    @Id
    @Getter @Setter
    private String groupId;// 小组id = 前缀+序号

    @Getter @Setter
    private Integer serial; // 小组序号，由系统自动产生

    @Getter @Setter
    private String preSerial; // 小组序号前缀

//    @Getter @Setter
//    private String name;// 小组名称

    @ManyToOne(fetch = FetchType.EAGER,targetEntity = User.class)
    @JoinColumn(name = "leader_id")
    @Getter @Setter
    private User leader;// 组长：组长与小组的关系是一对多

    @Getter @Setter
    private String tel; // 联系方式

    @Getter @Setter
    private int memberNum;// 组员数量, 其实可以去掉

    @Setter @Getter
    @ManyToMany(fetch= FetchType.EAGER,targetEntity= Student.class, mappedBy = "groupList") //
    private List<Student> members; // 分组成员， 分组——学生：多对多

    @Getter @Setter
    private String cfgId;
}
