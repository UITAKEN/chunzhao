package com.bupt.iclass.model;

import cn.afterturn.easypoi.excel.annotation.Excel;
import com.bupt.iclass.model.auth.Authority;
import com.bupt.iclass.model.auth.Role;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import javax.persistence.*;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * user model
 */
@Slf4j
@Entity
@Data
@AllArgsConstructor
@ApiModel("User Model")
// @Proxy(lazy = false)
public class User implements UserDetails {

    // @Autowired
    // RoleRepository roleRepository;

    @Id
    @ApiModelProperty("user id")
    @Excel(name = "ID")
    private Integer id;

    @ApiModelProperty("name")
    @Excel(name = "姓名", orderNum = "1")
    private String name;// 昵称/姓名

    @Excel(name = "密码", orderNum = "2")
    @ApiModelProperty("password")
    // @JsonIgnore
    private String password;

    @ApiModelProperty("username")
    @Excel(name = "用户名", orderNum = "3")
    private String userName;// user name


    @Excel(name = "角色", orderNum = "4")
    // @Transient
    // @JsonIgnore
    private int role; // 用户角色，一对一，一个用户只有一个角色

    @Excel(name = "首次登陆", orderNum = "5")
    private int isFirstLogin;

    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "r_id")
    private Role userRole; // 用户角色对应的Model类

    public User(){}

    public User(String userName) {
        this.userName = userName;
    }

    /**
     *以下为UserDetails接口相关的方法实现
     */



    @Override
    @JsonIgnore
    public Collection<? extends GrantedAuthority> getAuthorities() {
        // log.info(toString());
        Set<GrantedAuthority> authorities = new HashSet<GrantedAuthority>();
        List<Authority> roleAuthorities = userRole.getAuthorities();
        authorities.add(new SimpleGrantedAuthority(userRole.getRoleName()));

        /**
         * authorities.add(new SimpleGrantedAuthority(authority.getAuthName())
         */
        String rolePreFix = "ROLE_";
        for (Authority authority :
                roleAuthorities) {
            log.info("authority:" + authority.getAuthName());
            SimpleGrantedAuthority simpleGrantedAuthority = new SimpleGrantedAuthority(rolePreFix + authority.getAuthName());
            log.info("simpleGrantedAuthority:" + simpleGrantedAuthority.toString());
            authorities.add(simpleGrantedAuthority);
        }

        return authorities;
    }

    /**
     * 返回用户名，用户身份的唯一标识。此处使用用户ID作为用户名
     * @return
     */
    @Override
    @JsonIgnore
    public String getUsername() {
        return id.toString();
    }

    @Override
    @JsonIgnore
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    @JsonIgnore
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    @JsonIgnore
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    @JsonIgnore
    public boolean isEnabled() {
        return true;
    }
}
