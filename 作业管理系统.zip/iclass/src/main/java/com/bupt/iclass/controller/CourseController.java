package com.bupt.iclass.controller;

import com.alibaba.fastjson.JSONObject;
import com.bupt.iclass.model.Course;
import com.bupt.iclass.model.Response;
import com.bupt.iclass.model.User;
import com.bupt.iclass.model.Student;
import com.bupt.iclass.model.Teacher;
import com.bupt.iclass.repository.StudentRepository;
import com.bupt.iclass.service.CourseService;
import com.bupt.iclass.service.TeacherService;
import com.bupt.iclass.service.UserService;
import com.bupt.iclass.util.Util;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/course")
@Slf4j
@CrossOrigin
public class CourseController {
    @Autowired
    CourseService service;

    @Autowired
    TeacherService teacherService;

    @Autowired
    StudentRepository studentRepository;

    @Autowired
    UserService userService;

    /**
     * 获取所有课程
     * @return
     */
    @GetMapping("/courses")
    public Response getAllCourses() {
        List<Course> allCourse = service.findAllCourses();
        return new Response(allCourse,true);
    }

    @GetMapping("/{id}")
    public Response getCourse(@PathVariable("id") String id) {
        Optional<Course> optional = service.findById(id);
        return optional.map(course -> new Response(course,true)).orElseGet(() -> new Response(false,"error"));
    }

    @PostMapping("/add")
    public Response addCourse(Course course) {
        User currentUser = Util.getCurrentUser();
        Optional<Teacher> byId = teacherService.findById(currentUser.getId());
        Teacher teacher = byId.get();
        Date currentDate = new Date();
        course.setCreateDate(currentDate);
        course.setTeacher(teacher);
        // teacher.getCourses().add(course);
        // teacher.setCourses(teacher.getCourses()); // 保存教师创建的课程信息
        log.info(teacher.getCourses().toString());
        Course save = service.save(course);
        // Course save = service.save(course);
        if (save == null) return Response.err("创建课程失败，请重试");
        return Response.success(save);
    }

//    @GetMapping("/stus/{cid}")
//    public Response getStusByCourse(@PathVariable("cid") String cid) {
//        List<Student> students = studentRepository.findStudentsByCourseId(cid);
//        return Response.success(students);
//    }

    @GetMapping("/stus/{cid}")
    public Response test(@PathVariable("cid") String cid) {
        List<Integer> students = studentRepository.findStudentIdsByCourseId(cid);
        List<JSONObject> data = new ArrayList<>();
        for (Integer integer : students) {
            Student student = studentRepository.findById(integer).get();
            User user = userService.findById(integer).get();
            JSONObject jsonObject = new JSONObject();
            jsonObject.fluentPut("id", integer);
            jsonObject.fluentPut("name", user.getName());
            jsonObject.fluentPut("classId", student.getClassId());
            data.add(jsonObject);
        }
        return Response.success(data);
    }

}
