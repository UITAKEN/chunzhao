package com.bupt.iclass.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * 记录学生成绩， 试用原生SQL语句进行查询
 */
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Score {
    @Id
    private Integer id;

    // 课程对应的成绩
    private Integer stuId; // 学生id
    private String taskId; // 作业id
    private Integer groupScore; // 小组成绩
    private Integer personalScore; // 个人成绩
    private double score;// 总评分数
}
