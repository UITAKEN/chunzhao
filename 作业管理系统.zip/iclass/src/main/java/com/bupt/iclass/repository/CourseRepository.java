package com.bupt.iclass.repository;

import com.bupt.iclass.model.Course;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CourseRepository extends JpaRepository<Course, String> {
    Optional<Course> findById(String id);

    // 根据课程获取该课程的学生名单

}
