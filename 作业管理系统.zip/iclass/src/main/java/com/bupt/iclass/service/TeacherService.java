package com.bupt.iclass.service;

import com.bupt.iclass.model.Teacher;
import com.bupt.iclass.repository.TeacherRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TeacherService {
    @Autowired
    private TeacherRepository repository;
    public Optional<Teacher> findById(Integer id) {
        return repository.findById(id);
    }

    public List<Teacher> findAll() {
        return repository.findAll();
    }

    public Teacher save(Teacher teacher) {
        return repository.save(teacher);
    }
}
