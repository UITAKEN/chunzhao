package com.bupt.iclass.model;

/**
 * StudentX
 * 用户教师设置课程学生名单时对应的Excel
 */

import cn.afterturn.easypoi.excel.annotation.Excel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Id;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StudentX {
    @Id
    @Excel(name = "学号")
    private Integer id;
    @Excel(name = "姓名", orderNum = "1")
    private String name;
    @Excel(name = "班级", orderNum = "2")
    private String classId;
    @Excel(name = "学院", orderNum = "3")
    private String department;// 学院
    @Excel(name = "专业", orderNum = "4")
    private String major;// 专业
}
