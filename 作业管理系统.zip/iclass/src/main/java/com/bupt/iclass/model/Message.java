package com.bupt.iclass.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;

/**
 * 消息通知， 通知学生提交作业
 */
@Entity
@Data
@AllArgsConstructor
public class Message implements Serializable {


    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    Integer id;

    Integer taskId; // 作业id
    Integer StuId; // 学生id
    String message;

    public Message() {}
}
