package com.bupt.iclass.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;


@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class Admin {
    @Id
    private Integer id;

    private User user;// 表示共有的用户基本信息
}
