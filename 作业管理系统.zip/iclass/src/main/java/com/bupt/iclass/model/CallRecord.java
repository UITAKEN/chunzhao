package com.bupt.iclass.model;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * 学生点名记录
 */

@Entity
@Data
public class CallRecord {
    @Id
    private Integer id;

    private Integer sId; // 学生id
    private Integer cId; // 课程id

    private boolean isAttend; // 是否出勤
}
