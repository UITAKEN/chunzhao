package com.bupt.iclass.controller;

import com.alibaba.fastjson.JSONObject;
import com.bupt.iclass.model.Course;
import com.bupt.iclass.model.Homework;
import com.bupt.iclass.model.Response;
import com.bupt.iclass.model.User;
import com.bupt.iclass.model.Student;
import com.bupt.iclass.repository.HomeworkRepository;
import com.bupt.iclass.service.CourseService;
import com.bupt.iclass.service.HomeworkService;
import com.bupt.iclass.service.StudentService;
import com.bupt.iclass.service.UserService;
import com.bupt.iclass.util.Util;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/work")
@Slf4j
@CrossOrigin
public class HomeworkController {
    @Autowired
    HomeworkService service;
    @Autowired
    HomeworkRepository repository;
    @Autowired
    UserService userService;

    @Autowired
    StudentService studentService;

    @Autowired
    CourseService courseService;

    @GetMapping("/{id}")
    public Response getWork(@PathVariable("id") Integer id) {
        Optional<Homework> work = service.findById(id);
        return work.map(homeWork -> new Response(homeWork,true)).orElseGet(() -> new Response(false,"error"));
    }
    @GetMapping("/all")
    public Response getAllWorks() {
        List<Homework> works = service.findAllWorks();
        return new Response(works,true);
    }

    /**
     * 根据id删除已经布置的任务
     */
    @DeleteMapping("/{id}")
    public Response deleteWorkById(@PathVariable("id") Integer id) {
        int i = service.deleteById(id);
        if (i == 1) return new Response("",true);
        return new Response(false,"删除失败");
    }

    @PostMapping("/add")
    public Response addHomework(Homework homework, @RequestParam("courseId") String courseId, @RequestParam("deadTime") String deadline) throws ParseException {
        Course course = courseService.findById(courseId).get();
        Date current = new Date();
        homework.setCreateDate(current);
        homework.setCourse(course);

        Date deadlineDate = Util.dateFormat(deadline);
        homework.setDeadline(deadlineDate);

        Homework save = service.addHomework(homework);
        if (save == null)
            return Response.err("添加作业失败");
        return Response.success();
    }

    /**
     * 课程名称
     * 	作业
     * 	截止日期
     * 	任务描述
     */
    @GetMapping("/works/{id}")
    public Response getAllWorksByStuId(@PathVariable("id") Integer id) {
        User currentUser = userService.findById(id).get();
        Student student = studentService.findById(currentUser.getId()).get();
        List<Course> courses = student.getCourses();
        List<JSONObject> data = new ArrayList<>();
        for (Course course : courses) {
            List<Homework> works = course.getWorks();
            for (Homework work : works) {
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String format = dateFormat.format(work.getDeadline());
                String createDate = dateFormat.format(work.getCreateDate());
                JSONObject jsonObject = new JSONObject();
               jsonObject.fluentPut("courseName", course.getCourseName());
               jsonObject.fluentPut("title", work.getTitle());
               jsonObject.fluentPut("createDate", createDate);
               jsonObject.fluentPut("deadline",format);
               jsonObject.fluentPut("tasks", work.getTasks());
               jsonObject.fluentPut("percent", work.getPercent() + "%");
               data.add(jsonObject);
            }
        }
        return Response.success(data);
    }

    private JSONObject getJsonData(String courseName, String work, Date deadline, String desc ) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.fluentPut("courseName", courseName);
        jsonObject.fluentPut("work", work);
        jsonObject.fluentPut("deadline", deadline);
        jsonObject.put("desc", desc);

        log.info(jsonObject.toString());
        return jsonObject;
    }

    @PostMapping("/modify")
    public Response modifyTask(@RequestParam("id") Integer id, @RequestParam("percent") Integer percent) {
        Homework homework = service.findById(id).get();
        homework.setPercent(percent);
        Homework save = repository.save(homework);
        if (save != null)
            return Response.success(save);

        return Response.err("修改失败");
    }


}
