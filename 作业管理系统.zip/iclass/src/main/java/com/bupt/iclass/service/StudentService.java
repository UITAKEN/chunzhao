package com.bupt.iclass.service;

import com.bupt.iclass.model.Student;
import com.bupt.iclass.model.Teacher;
import com.bupt.iclass.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StudentService {
    @Autowired
    StudentRepository repository;

    public Optional<Student> findById(Integer id) {
        return repository.findById(id);
    }

    public Teacher findTeacherByStuId(Integer id) {
        // return repository.findByStuId(id);
        return null;
    }

    public Student save(Student student) {
        return repository.save(student);
    }

    public List<Student> findByDepartment(String department) {
        return repository.findByDepartment(department);
    }
}
