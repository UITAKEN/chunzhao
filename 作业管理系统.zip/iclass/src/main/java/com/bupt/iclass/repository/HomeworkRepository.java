package com.bupt.iclass.repository;

import com.bupt.iclass.model.Homework;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface HomeworkRepository extends JpaRepository<Homework, Integer> {
    Optional<Homework> findById(Integer id);

    @Override
    boolean existsById(Integer integer);
}
