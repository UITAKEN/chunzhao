package com.bupt.iclass.controller;

import com.alibaba.fastjson.JSONObject;
import com.bupt.iclass.model.*;
import com.bupt.iclass.repository.GroupRepository;
import com.bupt.iclass.repository.MessageRepository;
import com.bupt.iclass.repository.StudentRepository;
import com.bupt.iclass.repository.UserRepository;
import com.bupt.iclass.service.CourseService;
import com.bupt.iclass.service.HomeworkService;
import com.bupt.iclass.service.StudentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 负责处理学生相关的业务逻辑
 */
@RestController
@CrossOrigin
@RequestMapping("/stu")
@Slf4j
public class StudentController {
    @Autowired
    StudentService service;

    @Autowired
    HomeworkService homeWorkService;

    @Autowired
    CourseService courseService;

    @Autowired
    StudentRepository studentRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    GroupRepository groupRepository;

    @Autowired
    MessageRepository messageRepository;
    /**
     * 通过学生Id查找学生信息并返回
     * 此处由于Hibernate映射，学生的选课信息，以及课程作业已经返回给前端，可以在前端使用localStorage进行存储
     * @param id
     * @return
     */
    @GetMapping("/{id}")
    public Response getStudent(@PathVariable("id") Integer id) {
        Optional<Student> optionalStudent = service.findById(id);
        return optionalStudent.map(student -> new Response(student, true)).orElseGet(() -> new Response(false, "学生ID不存在"));
    }

    @GetMapping("/teacher/{id}")
    public Response getTeacher(@PathVariable("id") Integer id) {
        Teacher teacher = service.findTeacherByStuId(id);
        return new Response(teacher, true);
    }

    /**
     * 查找该学生所有的作业
     * @return
     */
    @GetMapping("/{id}/work")
    public Response getWorks(@PathVariable("id") Integer id) {
        Optional<Student> optionalStudent = service.findById(id);
        Student student = optionalStudent.get();
        return Response.success(student);
    }

    /**
     * 根据学生id获取学生的所有课程
     * @param id
     * @return
     */
    @GetMapping("/courses/{id}")
    public Response getCourses(@PathVariable("id") Integer id) {
        Optional<Student> optionalStudent = service.findById(id);
        Student student = optionalStudent.get();
        List<Course> courses = student.getCourses();
        List<JSONObject> jsonObjects = new ArrayList<>();
        for (Course course : courses) {
            User teacher = userRepository.findTeacherByCourseId(course.getCid());
            JSONObject jsonObject = new JSONObject();
            jsonData(jsonObjects, course, teacher, jsonObject);
        }
        return Response.success(jsonObjects);
//        return optionalStudent.map(student -> new Response(student.getCourses(), true)).orElseGet(() -> new Response(false, "学生ID不存在"));
    }

    static void jsonData(List<JSONObject> jsonObjects, Course course, User teacher, JSONObject jsonObject) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String formatDate = dateFormat.format(course.getCreateDate());
        jsonObject.fluentPut("cid", course.getCid());
        jsonObject.fluentPut("courseName", course.getCourseName());
        jsonObject.fluentPut("createDate", formatDate);
        jsonObject.fluentPut("intro", course.getIntro());
        jsonObject.fluentPut("teacher", teacher.getName());
        jsonObjects.add(jsonObject);
    }

    // 获取同学院的所有学生

    @GetMapping("/dep/{id}")
    public Response getStudentsByDep(@PathVariable("id") Integer id) {
        Optional<Student> optional = service.findById(id);
        Student student = optional.get();

        List<Student> students = service.findByDepartment(student.getDepartment());

        if (students == null)
            return Response.err("服务端错误");

        return Response.success(students);
    }

    @GetMapping("/all")
    public Response getAllStus() {
        List<Student> all = studentRepository.findAll();
        List<JSONObject> jsonObjectList = new ArrayList<>();
        for (Student student : all) {
            User user = student.getUser();
            JSONObject jsonObject = new JSONObject();
            jsonObject.fluentPut("id", user.getId());
            jsonObject.fluentPut("name", user.getName());
            jsonObject.fluentPut("classId", student.getClassId());
            jsonObject.fluentPut("department", student.getDepartment());
            jsonObject.fluentPut("major", student.getMajor());
            jsonObjectList.add(jsonObject);
        }
        return Response.success(jsonObjectList);
    }

    @GetMapping("/groups/{id}")
    public Response findAllGroupsByStuId(@PathVariable("id") Integer stuId) {
        List<StuGroup> groups = groupRepository.findAllGroupsByStuId(stuId);
        List<JSONObject> data = new ArrayList<>();
        for (StuGroup group : groups) {
            String groupId = group.getGroupId();
            List<Student> members = group.getMembers();
            List<JSONObject> memberData = new ArrayList<>();
            for (Student student : members) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.fluentPut("sid", student.getSid());
                jsonObject.fluentPut("name", student.getUser().getName());
                jsonObject.fluentPut("classId", student.getClassId());
                jsonObject.fluentPut("major", student.getMajor());

                memberData.add(jsonObject);
            }

            User leader = group.getLeader();

            JSONObject jsonObject = new JSONObject();
            jsonObject.fluentPut("groupId", groupId);
            jsonObject.fluentPut("leader", leader.getName());
            jsonObject.fluentPut("tel", group.getTel());
            jsonObject.fluentPut("members", memberData);
            jsonObject.fluentPut("count", memberData.size());
            data.add(jsonObject);
        }

        return Response.success(data);
    }

    /**
     * 系统通知消息，提醒提交作业
     * @param stuId
     * @return
     */
    @GetMapping("/message/{id}")
    public Response getMessage(@PathVariable("id") Integer stuId) {
        List<Message> messages = messageRepository.findByStuId(stuId);
        List<JSONObject> data = new ArrayList<>();

        for (Message message : messages) {
            Integer taskId = message.getTaskId();
            Homework homework = homeWorkService.findById(taskId).get();

            Date deadline = homework.getDeadline();
            Date current = new Date();

            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            String deadDate = format.format(deadline);

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(current);
            calendar.set(Calendar.DAY_OF_MONTH, calendar.get(Calendar.DAY_OF_MONTH)+3);
            int compare = calendar.get(Calendar.DATE);
            calendar.setTime(deadline);
            calendar.set(Calendar.DAY_OF_MONTH, calendar.get(Calendar.DAY_OF_MONTH));
            int deadDay = calendar.get(Calendar.DATE);

            log.info("compare:" + compare + " " + deadDay);

            if (compare <= deadDay) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.fluentPut("id", message.getId());
                jsonObject.fluentPut("title", homework.getTitle());
                jsonObject.fluentPut("message", message.getMessage());
                jsonObject.fluentPut("tasks", homework.getTasks());
                jsonObject.fluentPut("deadline",deadDate);
                data.add(jsonObject);
            }
        }

        return Response.success(data);
    }
}
