package com.bupt.iclass.util;

// import org.springframework.security.authentication.;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.crypto.password.*;

import java.math.BigInteger;
import java.security.MessageDigest;
// import org.springframework.util.DigestUtils;
/**
 * 自定义加密方式
 */

@Slf4j
public class Md5Encoder implements PasswordEncoder {
    private PasswordEncoder passwordEncoder = new MessageDigestPasswordEncoder("MD5");
    @Override
    public String encode(CharSequence rawPassword) {
        return passwordEncoder.encode(rawPassword);


        // return DigestUtils.md5DigestAsHex(rawPassword.toString().getBytes());
        // Md5PasswordEncoder encoder = new Md5PasswordEncoder();
        // return encoder.encodePassword(rawPassword.toString(), SALT);
        // return "";
    }

    @Override
    public boolean matches(CharSequence rawPassword, String encodedPassword) {
        // String raw = rawPassword.toString();
        // Md5PasswordEncoder encoder = new Md5PasswordEncoder();
        // return encoder.isPasswordValid(encodedPassword, rawPassword.toString(), SALT);
        // log.info("raw:" + rawPassword);
        // log.info("encoded:" + encodedPassword);
        return passwordEncoder.matches(rawPassword,encodedPassword);
        // return false;
    }

    public static String encode(String str) {
        try {
            // 生成一个MD5加密计算摘要
            MessageDigest md = MessageDigest.getInstance("MD5");
            // 计算md5函数
            md.update(str.getBytes());
            // digest()最后确定返回md5 hash值，返回值为8为字符串。因为md5 hash值是16位的hex值，实际上就是8位的字符
            // BigInteger函数则将8位的字符串转换成16位hex值，用字符串来表示；得到字符串形式的hash值
            return new BigInteger(1, md.digest()).toString(16);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "error";
    }
}
