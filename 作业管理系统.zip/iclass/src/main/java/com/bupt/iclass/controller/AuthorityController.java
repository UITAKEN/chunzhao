package com.bupt.iclass.controller;

import com.bupt.iclass.model.Response;
import com.bupt.iclass.model.auth.Authority;
import com.bupt.iclass.model.auth.Role;
import com.bupt.iclass.repository.AuthorityRepository;
import com.bupt.iclass.repository.RoleRepository;
import com.bupt.iclass.service.AuthorityService;
import com.bupt.iclass.service.RoleService;
import com.bupt.iclass.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin
@RequestMapping("/auth")
public class AuthorityController {
    @Autowired
    AuthorityService service;

    @Autowired
    RoleRepository roleRepository;

    @Autowired
    AuthorityRepository authRepository;


    @Autowired
    UserService userService;

    @GetMapping("/{id}")
    public Response getAuth(@PathVariable("id") Integer id) {
        Optional<Authority> optional = service.findById(id);
        return optional.map(authority -> new Response(authority,true)).orElseGet(() -> new Response(false,"error"));
    }

    @GetMapping("/auths")
    public Response getAllRoles() {
        List<Authority> authorities = service.findAllAuthorities();
        return new Response(authorities,true);
    }



    @PostMapping("auth/add")
    public Authority addAuth(Authority authority) {
        return authRepository.save(authority);
    }

    @PostMapping("/test/role/add")
    public Role addRole1() {
        Role role = new Role();
        role.setRoleId(5);
        role.setRoleName("test");
        role.setRoleIntro("测试角色");
        Authority authority = new Authority();
        authority.setAuthId(6);
        // authority.setAuthName("test");
        // authority.setAuthIntro("测试权限");
        List<Authority> authorities = new ArrayList<>();
        authorities.add(authority);
        Authority authority1 = new Authority();
        authority1.setAuthId(5);
        authorities.add(authority1);
        role.setAuthorities(authorities);
        return roleRepository.save(role);
    }
}
